--[[
        advance_guide_data.lua
        exported by excel2lua.py
        from file:advance_guide_data.xlsx
--]]


Config = Config or {}
Config.AdvanceGuideData = Config.AdvanceGuideData or {}

---------------------data_group_list start--------------------
Config.AdvanceGuideData.data_group_list_length = 3
Config.AdvanceGuideData.data_group_list = {
 [1] = {
    [1]={
[1] = {id=1,is_parner_form=1,partner_list={30004,30003,30022,10001,10008},level=0,is_goto=0,name="新手推荐",group_id=1,des_label="雅典娜<div fontcolor=#d63cfc>（狂怒套）</div>,哈迪斯<div fontcolor=#d63cfc>（迅影狂怒套）</div>,吸血伯爵<div fontcolor=#d63cfc>（狂怒套）</div>,亚瑟<div fontcolor=#d63cfc>（迅影勇气套）</div>;首充可获得超强输出雅典娜，哈迪斯和吸血伯爵搭配能稳定控制敌方单位，亚瑟是前期十分好用的辅助控制",extra={},group=1},
[2] = {id=2,is_parner_form=1,partner_list={30008,20007,30002,20013,30023},level=0,is_goto=0,name="冰冻增伤",group_id=1,des_label="冰雪女王<div fontcolor=#d63cfc>（暴击预言者套）</div>,波塞冬<div fontcolor=#d63cfc>（速度秩序套）</div>,游侠射手<div fontcolor=#d63cfc>（速度预言者套）</div>,水元素<div fontcolor=#d63cfc>（暴击预言者套）</div>;依靠获得回合不断控制敌人，控制英雄需要堆高速度，比对面先出手",extra={},group=1},
[3] = {id=3,is_parner_form=1,partner_list={30010,10002,30012,20002,30023},level=0,is_goto=0,name="灼烧暴击",group_id=1,des_label="炎魔之王<div fontcolor=#d63cfc>（攻击雷霆套）</div>,炽天使<div fontcolor=#d63cfc>（暴击雷霆套）</div>,凯瑟琳<div fontcolor=#d63cfc>（命中征服套）</div>;配合2个加攻击暴击辅助，前2回合直接结束战斗",extra={},group=1},
[4] = {id=4,is_parner_form=1,partner_list={30007,30013,30016,30008,20009},level=0,is_goto=0,name="诅咒输出",group_id=1,des_label="阿努比斯<div fontcolor=#d63cfc>（暴伤狂怒套）</div>,路西法<div fontcolor=#d63cfc>（暴伤狂怒套）</div>,月之祭司<div fontcolor=#d63cfc>（生命战吼套）</div>,娜迦公主<div fontcolor=#d63cfc>（速度迅影套）</div>;诅咒伤害可直接击杀敌方全部单位,月之祭司保证2波怪时刷新CD",extra={},group=1}},
    [2]={
[1] = {id=1,is_parner_form=1,partner_list={30024,30006,20019,30009},level=0,is_goto=0,name="肉盾防守",group_id=2,des_label="影刹<div fontcolor=#d63cfc>（生命预言者套）</div>,盖亚<div fontcolor=#d63cfc>（防御秩序套）</div>,憎恶<div fontcolor=#d63cfc>（生命勇气套）</div>,凯兰崔尔<div fontcolor=#d63cfc>（生命预言者套）</div>;敌人较难直接击杀己方任何一个英雄，憎恶反伤消耗",extra={},group=1},
[2] = {id=2,is_parner_form=1,partner_list={20023,20015,30006,10001},level=0,is_goto=0,name="免疫防守",group_id=2,des_label="岩石傀儡<div fontcolor=#d63cfc>(抵抗反击套)</div>,吟游诗人<div fontcolor=#d63cfc>(生命预言者套)</div>,盖亚<div fontcolor=#d63cfc>(防御秩序套)</div>,亚瑟<div fontcolor=#d63cfc>(生命战吼套)</div>;没有任何攻击能力,纯防守阵容，用于防守竞技场",extra={},group=1},
[3] = {id=3,is_parner_form=1,partner_list={30022,30003,30023,20014},level=0,is_goto=0,name="高速控制",group_id=2,des_label="雷霆狮鹫<div fontcolor=#d63cfc>（速度迅影套）</div>,艾蕾莉亚<div fontcolor=#d63cfc>（速度信仰套）</div>,哈迪斯<div fontcolor=#d63cfc>（命中征服套）</div>,吸血伯爵<div fontcolor=#d63cfc>（暴伤狂怒套）</div>;高速控制对手，且输出足够；惧怕净化免疫",extra={},group=1}},
    [3]={
[1] = {id=1,is_parner_form=1,partner_list={30002,20007,30016,20009,30008},level=0,is_goto=0,name="冰冻控制",group_id=3,des_label="娜迦公主<div fontcolor=#d63cfc>（速度迅影套）</div>,波塞冬<div fontcolor=#d63cfc>（速度秩序套）</div>,游侠射手<div fontcolor=#d63cfc>（速度征服套）</div>,月之祭司<div fontcolor=#d63cfc>（生命战吼套）</div>;抢1速稳定控制敌人;惧怕敌人1速控制秒杀",extra={},group=1},
[2] = {id=2,is_parner_form=1,partner_list={30016,30007,30001,20015,30025},level=0,is_goto=0,name="重置冷却",group_id=3,des_label="赫拉<div fontcolor=#d63cfc>（速度迅影套）</div>,宙斯<div fontcolor=#d63cfc>（命中迅影套）</div>,阿努比斯<div fontcolor=#d63cfc>（暴伤狂怒套）</div>,月之祭司<div fontcolor=#d63cfc>（生命战吼套）</div>;破敌方免疫且控制敌方，依靠加BUFF后的阿努比斯2套带走",extra={},group=1},
[3] = {id=3,is_parner_form=1,partner_list={30011,20016,20015,30009,20011},level=0,is_goto=0,name="四保一",group_id=3,des_label="黑暗之主<div fontcolor=#d63cfc>（暴击雷霆套）</div>,4个辅助都为生命预言者套装；保证输出不死，逐个点杀",extra={},group=1},
[4] = {id=4,is_parner_form=1,partner_list={20011,30021,20015,20014,20017},level=0,is_goto=0,name="睡杀单点",group_id=3,des_label="竖琴海妖<div fontcolor=#d63cfc>（命中迅影套）</div>,魅魔女王<div fontcolor=#d63cfc>（暴伤狂怒套）</div>,吟游诗人<div fontcolor=#d63cfc>（生命预言者套）</div>,雷霆狮鹫<div fontcolor=#d63cfc>（速度迅影套）</div>;群体睡眠敌方，单体点杀关键英雄",extra={},group=1}},
    [4]={
[1] = {id=1,is_parner_form=0,partner_list={},level=1,is_goto=1,name="提升阶数",cli_label="evt_partner_strength_treasure",group_id=4,des_label="提升英雄阶数能提升英雄基础属性",icon=13,extra={},group=1},
[2] = {id=2,is_parner_form=0,partner_list={},level=1,is_goto=1,name="提升等级",cli_label="evt_partner_lev",group_id=4,des_label="提升英雄等级能提升英雄基础属性",icon=14,extra={},group=1},
[3] = {id=3,is_parner_form=0,partner_list={},level=1,is_goto=1,name="提升星级",cli_label="evt_partner_star_num",group_id=4,des_label="提升英雄星级，能增加大量基础属性",icon=15,extra={},group=1},
[4] = {id=4,is_parner_form=0,partner_list={},level=1,is_goto=1,name="提升技能",cli_label="evt_partner_skill",group_id=4,des_label="使用符石提升技能等级，技能更强力",icon=16,extra={},group=1},
[5] = {id=5,is_parner_form=0,partner_list={},level=22,is_goto=1,name="提升装备",cli_label="evt_partner_eqm",group_id=4,des_label="给英雄穿戴装备提升绿字属性",icon=17,extra={},group=1}}},
 [2] = {
    [1]={
[1] = {id=1,is_parner_form=0,partner_list={},level=6,is_goto=1,name="通关副本",cli_label="evt_dungeon_pass",group_id=1,des_label="通关普通副本可获得领主经验",icon=12,extra={3},group=2},
[2] = {id=2,is_parner_form=0,partner_list={},level=11,is_goto=1,name="日常任务",cli_label="evt_daily_quest",group_id=1,des_label="完成日常任务能获得大量领主经验",icon=9,extra={},group=2},
[3] = {id=3,is_parner_form=0,partner_list={},level=35,is_goto=1,name="诸神大陆",cli_label="evt_bigworld",group_id=1,des_label="在诸神大陆中击杀怪物获取经验",icon=28,extra={},group=2}},
    [2]={
[1] = {id=1,is_parner_form=0,partner_list={},level=15,is_goto=1,name="炼金场",cli_label="evt_trade",group_id=2,des_label="炼金场生产金币，亦可花费钻石换取金币",icon=1,extra={1},group=2},
[2] = {id=2,is_parner_form=0,partner_list={},level=24,is_goto=1,name="巨龙副本",cli_label="evt_dungeon_enter",group_id=2,des_label="挑战巨龙副本，可获得大量金币",icon=26,extra={6},group=2},
[3] = {id=3,is_parner_form=0,partner_list={},level=26,is_goto=1,name="英雄远征",cli_label="evt_expedition",group_id=2,des_label="挑战英雄远征可获得金币",icon=8,extra={},group=2}},
    [3]={
[1] = {id=1,is_parner_form=0,partner_list={},level=1,is_goto=1,name="充值",cli_label="evt_pay",group_id=3,des_label="前往充值购买钻石",icon=3,extra={},group=2},
[2] = {id=2,is_parner_form=0,partner_list={},level=1,is_goto=1,name="主线任务",cli_label="evt_main_quest",group_id=3,des_label="完成每一章主线任务可获得钻石",icon=9,extra={},group=2},
[3] = {id=3,is_parner_form=0,partner_list={},level=1,is_goto=1,name="剧情副本",cli_label="evt_dungeon_pass",group_id=3,des_label="开启剧情副本宝箱可获得钻石",icon=12,extra={3},group=2},
[4] = {id=4,is_parner_form=0,partner_list={},level=1,is_goto=1,name="地下城副本",cli_label="evt_dungeon_pass",group_id=3,des_label="开启地下城副本宝箱可获得钻石",icon=6,extra={3,1},group=2},
[5] = {id=5,is_parner_form=0,partner_list={},level=18,is_goto=1,name="试练塔首通",cli_label="evt_dungeon_enter",group_id=3,des_label="试炼塔每层首次通关可获得大量钻石",icon=2,extra={4},group=2}},
    [4]={
[1] = {id=1,is_parner_form=0,partner_list={},level=6,is_goto=1,name="好友赠送",cli_label="evt_friend_present",group_id=4,des_label="领取好友赠送的体力",icon=27,extra={},group=2},
[2] = {id=2,is_parner_form=0,partner_list={},level=10,is_goto=1,name="许愿池",cli_label="evt_wish",group_id=4,des_label="每天定时赠送大量体力",icon=10,extra={},group=2},
[3] = {id=3,is_parner_form=0,partner_list={},level=14,is_goto=1,name="港口",cli_label="evt_port",group_id=4,des_label="领取停泊在港口的飞船的体力",icon=7,extra={},group=2},
[4] = {id=4,is_parner_form=0,partner_list={},level=6,is_goto=1,name="购买体力",cli_label="evt_trade",group_id=4,des_label="点击体力图标花费钻石购买体力",icon=19,extra={3},group=2}},
    [5]={
[1] = {id=1,is_parner_form=0,partner_list={},level=6,is_goto=1,name="活动",cli_label="evt_activity",group_id=5,des_label="部分活动可用钻石直购装备",icon=5,extra={},group=2},
[2] = {id=2,is_parner_form=0,partner_list={},level=16,is_goto=1,name="神秘商店",cli_label="evt_mystical_shop",group_id=5,des_label="可用金币在神秘商店购买装备",icon=11,extra={},group=2},
[3] = {id=3,is_parner_form=0,partner_list={},level=20,is_goto=1,name="制作装备",cli_label="evt_research",group_id=5,des_label="花费一定材料制作装备",icon=18,extra={3},group=2},
[4] = {id=4,is_parner_form=0,partner_list={},level=22,is_goto=1,name="装备副本",cli_label="evt_dungeon_enter",group_id=5,des_label="挑战装备副本可获得珍稀装备",icon=17,extra={1},group=2}},
    [6]={
[1] = {id=1,is_parner_form=0,partner_list={},level=16,is_goto=1,name="竞技积分",cli_label="evt_arena_fight",group_id=6,des_label="每天挑战竞技场能获得竞技积分",icon=20,extra={},group=2},
[2] = {id=2,is_parner_form=0,partner_list={},level=17,is_goto=1,name="联盟积分",cli_label="evt_league",group_id=6,des_label="参与联盟相关玩法可获得大量积分",icon=21,extra={},group=2},
[3] = {id=3,is_parner_form=0,partner_list={},level=26,is_goto=1,name="远征积分",cli_label="evt_expedition",group_id=6,des_label="挑战英雄远征玩法可获得积分",icon=22,extra={},group=2},
[4] = {id=4,is_parner_form=0,partner_list={},level=28,is_goto=1,name="段位积分",cli_label="evt_rank_match_fight",group_id=6,des_label="挑战段位赛可获得段位积分",icon=23,extra={},group=2},
[5] = {id=5,is_parner_form=0,partner_list={},level=35,is_goto=1,name="天梯积分",cli_label="evt_sky_ladder_fight",group_id=6,des_label="参与天梯玩法可获得积分",icon=25,extra={},group=2}},
    [7]={
[1] = {id=1,is_parner_form=0,partner_list={},level=9,is_goto=1,name="分解英雄",cli_label="evt_research",group_id=7,des_label="分解暂时不用的英雄能获得大量神格",icon=24,extra={1},group=2},
[2] = {id=2,is_parner_form=0,partner_list={},level=9,is_goto=1,name="分解碎片",cli_label="evt_research",group_id=7,des_label="分解不需要的英雄碎片能获得神格",icon=24,extra={1},group=2},
[3] = {id=3,is_parner_form=0,partner_list={},level=18,is_goto=1,name="挑战试练塔",cli_label="evt_dungeon_enter",group_id=7,des_label="挑战试炼塔可获得神格奖励",icon=2,extra={4},group=2}}},
 [3] = {
    [1]={
[1] = {id=1,is_parner_form=0,partner_list={},level=1,is_goto=0,name="英雄速度",group_id=1,des_label="英雄速度高低决定攻击条增长快慢",icon=30,extra={},group=3,tips_des="速度越快，攻击条增长越快，加速度buff可百分比增加整体速度总和。攻击条相同的情况下，速度高的先出手。"},
[2] = {id=2,is_parner_form=0,partner_list={},level=1,is_goto=0,name="行动条",group_id=1,des_label="行动条满即可达到出手条件",icon=31,extra={},group=3,tips_des="1、部分英雄技能可直接改变英雄行动条，行动条满即可获得回合\n2、若多个英雄行动条满，则先满条的先出手，行动条进度一致的，速度快的优先出手\n3、每个英雄行动结束后，全体单位增加固定比例的行动条。"},
[3] = {id=3,is_parner_form=0,partner_list={},level=1,is_goto=0,name="效果命中和抵抗",group_id=1,des_label="效果命中和抵抗决定最终是否控制成功",icon=32,extra={},group=3,tips_des="效果命中可增加控制或者减益效果成功的概率，效果抵抗可降低受到控制或减益效果的概率"}}}
}
Config.AdvanceGuideData.data_group_list_fun = function(key)
    local data =Config.AdvanceGuideData.data_group_list[key]
    if DATA_DEBUG and data == nil then
        print('( Config.AdvanceGuideData.data_group_list['..key..'])not found') return
    end
    return data
end
---------------------data_group_list end--------------------
---------------------data_group_name start--------------------
Config.AdvanceGuideData.data_group_name_length = 3
Config.AdvanceGuideData.data_group_name = {
 [1] = {
    [1]={group=1,is_parner_form=1,group_name="英雄指引",group_id=1,sec_name="剧情推图"},
    [2]={group=1,is_parner_form=1,group_name="英雄指引",group_id=2,sec_name="四人竞技"},
    [3]={group=1,is_parner_form=1,group_name="英雄指引",group_id=3,sec_name="五人竞技"},
    [4]={group=1,is_parner_form=0,group_name="英雄指引",group_id=4,sec_name="提升英雄"},
    [5]={group=1,is_parner_form=0,group_name="英雄指引",group_id=5,sec_name="游戏帮助"}},
 [2] = {
    [1]={group=2,is_parner_form=0,group_name="资源获取",group_id=1,sec_name="我要经验"},
    [2]={group=2,is_parner_form=0,group_name="资源获取",group_id=2,sec_name="我要金币"},
    [3]={group=2,is_parner_form=0,group_name="资源获取",group_id=3,sec_name="我要钻石"},
    [4]={group=2,is_parner_form=0,group_name="资源获取",group_id=4,sec_name="我要体力"},
    [5]={group=2,is_parner_form=0,group_name="资源获取",group_id=5,sec_name="我要装备"},
    [6]={group=2,is_parner_form=0,group_name="资源获取",group_id=6,sec_name="我要积分"},
    [7]={group=2,is_parner_form=0,group_name="资源获取",group_id=7,sec_name="我要神格"}},
 [3] = {
    [1]={group=3,is_parner_form=0,group_name="游戏帮助",group_id=1,sec_name="战斗规则"}}
}
Config.AdvanceGuideData.data_group_name_fun = function(key)
    local data =Config.AdvanceGuideData.data_group_name[key]
    if DATA_DEBUG and data == nil then
        print('( Config.AdvanceGuideData.data_group_name['..key..'])not found') return
    end
    return data
end
---------------------data_group_name end--------------------
