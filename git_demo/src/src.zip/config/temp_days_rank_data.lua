--[[
        temp_days_rank_data.lua
        exported by excel2lua.py
        from file:temp_days_rank_data.xlsx
--]]


Config = Config or {}
Config.TempDaysRankData = Config.TempDaysRankData or {}

---------------------data_rank_list start--------------------
Config.TempDaysRankData.data_rank_list_length = 19
Config.TempDaysRankData.data_rank_list = {
 [1] = {
    [1]={id=1,rank_type=9,name="剧情推图",jump=9,ico=9,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>剧情副本</div>通关进度进行排名，通关数量越多，排名越高",tips_str="1、根据冒险家观星次数进行排名，观星次数越高，排名越高\n2、若次数相同的情况下，先到达该次数的冒险者排名较高"}},
 [2] = {
    [1]={id=2,rank_type=15,name="神界冒险",jump=15,ico=15,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>神界冒险中探索度</div>排名，探索度越高，排名越高",tips_str="1、根据冒险家在武进试炼中排名，排名越高，奖励越丰富\n2、合理搭配阵容能通关更多无尽试炼关卡"}},
 [3] = {
    [1]={id=3,rank_type=14,name="最强英雄",jump=14,ico=14,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>最高战力英雄</div>排名，战力越高，排名越高",tips_str="1、根据冒险家参与召唤的次数进行排名，召唤次数越高，排名越高\n2、若次数相同的情况下，先达到该次数的冒险家排名较高"}},
 [4] = {
    [1]={id=4,rank_type=23,name="消费排行榜",jump=23,ico=12,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>蓝钻消耗总数</div>排名，消耗数量越多，排名越高",tips_str="1、根据冒险家历史上阵最高战力排名，战力越高，排名越高\n2、若上阵总战力相同的情况下，先到达该战力的冒险家排名较高\n3、通过各种玩法获取资源提升阵上英雄战力"}},
 [5] = {
    [1]={id=5,rank_type=27,name="圣器比拼",jump=27,ico=32,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>圣器战力</div>进行排名，战力越高，排名越高",tips_str="1、根据冒险家消耗蓝钻数量进行排名，数量越多，排名越高\n2、若消耗数相同的情况下，先到达该数量的冒险家排名较高"}},
 [6] = {
    [1]={id=6,rank_type=19,name="星命之耀",jump=19,ico=13,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>星命总战力</div>排名，战力越高，排名越高",tips_str="1、根据冒险家历史上阵最高战力排名，战力越高，排名越高\n2、若上阵总战力相同的情况下，先到达该战力的冒险家排名较高\n3、通过各种玩法获取资源提升阵上英雄战力"}},
 [7] = {
    [1]={id=7,rank_type=11,name="武道宗师",jump=11,ico=11,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>竞技场</div>排名，排名越高奖励越丰富",tips_str="1、根据冒险家上阵英雄宝石总等级进行排名，宝石等级越高，排名越高\n2、若宝石总等级相同的情况下，先达到总等级的玩家排名较高"}},
 [8] = {
    [1]={id=8,rank_type=1021,name="炫彩宝石",jump=21,ico=21,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>宝石总等级</div>进行排名，宝石总等级越高，排名越高",tips_str="1、根据冒险家通关星命塔层数排名，通关层数越高，排名越高\n2、若通关层数相同的情况下，先通关该层的冒险家排名较高\n3、通过提升阵容战力、针对当前星命塔战斗作出上阵安排或者阵法调整可以更容易通关更高层数"}},
 [9] = {
    [1]={id=9,rank_type=26,name="圣器比拼",jump=26,ico=26,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>圣器战力</div>进行排名，战力越高，排名越高",tips_str="1、根据冒险家参与寻宝的次数进行排名，寻宝次数越多，排名越高\n2、若次数相同的情况下，先达到该次数的冒险家排名较高"}},
 [10] = {
    [1]={id=10,rank_type=1024,name="观星大师",jump=24,ico=24,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>观星次数</div>进行排名，次数越多，排名越高",tips_str="1、根据冒险家在武进试炼中排名，排名越高，奖励越丰富\n2、合理搭配阵容能通关更多无尽试炼关卡"}},
 [11] = {
    [1]={id=11,rank_type=1018,name="无尽试炼",jump=18,ico=18,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>无尽试炼</div>排名决定，排名越高奖励越丰富",tips_str="1、根据冒险家剧情副本通关进度进行排名，通关数量越多，排名越高\n2、若通关进度相同的情况下，先达到关卡的玩家排名较高\n3、快速提升队伍战力，可以通关更多关卡"}},
 [12] = {
    [1]={id=12,rank_type=1022,name="召唤排行榜",jump=22,ico=22,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>英雄召唤</div>次数进行排名，召唤次数越多，排名越高",tips_str="1、根据冒险家神界冒险中探索度排名，探索度越高，排名越高\n2、若探索度相同的情况下，先达到该探索度的玩家排名较高\n3、通过挂机或者快速作战可以获取冒险情报来进行冒险"}},
 [13] = {
    [1]={id=13,rank_type=25,name="最强阵容",jump=25,ico=25,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>历史上阵最高战力</div>排名，战力越高，排名越高",tips_str="1、根据冒险家最高战力英雄排名，英雄战力越高，排名越高\n2、若战力相同的情况下，先到达该战力的英雄排名较高\n3、通过升级突破提升英雄等级、提升装备品质和装备精炼等能够提升英雄战力"}},
 [14] = {
    [1]={id=14,rank_type=1023,name="消费排行榜",jump=23,ico=23,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>蓝钻消耗总数</div>排名，消耗数量越多，排名越高",tips_str="1、根据冒险家消耗蓝钻数量进行排名，数量越多，排名越高\n2、若消耗数相同的情况下，先到达该数量的冒险家排名较高"}},
 [15] = {
    [1]={id=15,rank_type=12,name="超神阵容",jump=12,ico=12,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>历史上阵最高战力</div>排名，战力越高，排名越高",tips_str="1、根据冒险家圣器战力进行排名，圣器战力越高，排名越高\n2、若圣器战力相同的情况下，先达到该战力的玩家排名较高\n3、通过圣器副本和推图可提高圣器战力"}},
 [16] = {
    [1]={id=16,rank_type=31,name="炫彩宝石",jump=31,ico=31,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>宝石总等级</div>进行排名，宝石总等级越高，排名越高",tips_str="1、根据冒险家星命总战力排名，星命总战力越高，排名越高\n2、若星命总战力相同的情况下，先到达该战力的冒险家排名较高\n3、通过提升命格品质，升级星命来提升星命战力"}},
 [17] = {
    [1]={id=17,rank_type=10,name="爬塔达人",jump=10,ico=10,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>星命塔</div>通关层数进行排名，通关层数越高，排名越高",tips_str="1、根据冒险家在竞技场中排名，排名越高，奖励越丰富\n2、通过购买次数挑战能够获得更高竞技积分"}},
 [18] = {
    [1]={id=18,rank_type=28,name="寻宝专家",jump=28,ico=22,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>寻宝</div>次数进行排名，寻宝次数越多，排名越高",tips_str="1、根据冒险家上阵英雄宝石总等级进行排名，宝石等级越高，排名越高\n2、若宝石总等级相同的情况下，先达到总等级的玩家排名较高"}},
 [19] = {
    [1]={id=19,rank_type=29,name="无尽试炼",jump=29,ico=18,tips_rule="活动期间，根据冒险家<div fontcolor=#3dbf5f>无尽试炼</div>排名决定，排名越高奖励越丰富",tips_str="1、根据冒险家圣器战力进行排名，圣器战力越高，排名越高\n2、若圣器战力相同的情况下，先达到该战力的玩家排名较高\n3、通过圣器副本和推图可提高圣器战力"}}
}
Config.TempDaysRankData.data_rank_list_fun = function(key)
    local data =Config.TempDaysRankData.data_rank_list[key]
    if DATA_DEBUG and data == nil then
        print('( Config.TempDaysRankData.data_rank_list['..key..'])not found') return
    end
    return data
end
---------------------data_rank_list end--------------------
---------------------data_rank_data start--------------------
Config.TempDaysRankData.data_rank_data_length = 19
Config.TempDaysRankData.data_rank_data = {
 [1] = {
    [1]={id=1,effect_list={50101,34001,10152},high=1,low=1,rewards={{50113,1},{30030,1},{10412,3},{10301,600},{2,300000}}},
    [2]={id=1,effect_list={50101,34001,10152},high=2,low=2,rewards={{30024,2},{10412,3},{10301,500},{2,200000}}},
    [3]={id=1,effect_list={34001,10152},high=3,low=3,rewards={{30024,1},{10412,2},{10301,400},{2,100000}}},
    [4]={id=1,effect_list={10152},high=5,low=4,rewards={{10412,2},{10301,320},{2,80000}}},
    [5]={id=1,effect_list={10151},high=10,low=6,rewards={{10412,1},{10301,240},{2,50000}}},
    [6]={id=1,effect_list={10151},high=20,low=11,rewards={{10412,1},{10301,160},{2,20000}}}},
 [2] = {
    [1]={id=2,effect_list={50107,10421,10996},high=1,low=1,rewards={{50114,1},{10421,1},{10030,10},{10102,600},{2,300000}}},
    [2]={id=2,effect_list={10420,10996},high=2,low=2,rewards={{10420,2},{10030,8},{10102,500},{2,200000}}},
    [3]={id=2,effect_list={10420,10996},high=3,low=3,rewards={{10420,1},{10030,6},{10102,400},{2,100000}}},
    [4]={id=2,effect_list={10996},high=5,low=4,rewards={{10030,4},{10102,320},{2,80000}}},
    [5]={id=2,effect_list={10995},high=10,low=6,rewards={{10030,3},{10102,240},{2,50000}}},
    [6]={id=2,effect_list={10995},high=20,low=11,rewards={{10030,2},{10102,160},{2,20000}}}},
 [3] = {
    [1]={id=3,effect_list={50106,30030,10412},high=1,low=1,rewards={{50115,1},{35113,3},{13,50},{11,1200},{2,300000}}},
    [2]={id=3,effect_list={30024,10412},high=2,low=2,rewards={{35113,2},{13,40},{11,1000},{2,200000}}},
    [3]={id=3,effect_list={30024,10412},high=3,low=3,rewards={{35113,1},{13,30},{11,800},{2,100000}}},
    [4]={id=3,effect_list={10412},high=5,low=4,rewards={{13,20},{11,640},{2,80000}}},
    [5]={id=3,effect_list={10412},high=10,low=6,rewards={{13,10},{11,480},{2,50000}}},
    [6]={id=3,effect_list={10412},high=20,low=11,rewards={{13,5},{11,320},{2,20000}}}},
 [4] = {
    [1]={id=4,effect_list={50117,4},high=1,low=1,rewards={{50116,1},{30030,1},{10102,1200},{10301,600},{2,300000}}},
    [2]={id=4,effect_list={4},high=2,low=2,rewards={{30024,2},{10102,1000},{10301,500},{2,200000}}},
    [3]={id=4,effect_list={4},high=3,low=3,rewards={{30024,1},{10102,800},{10301,400},{2,100000}}},
    [4]={id=4,effect_list={},high=5,low=4,rewards={{10102,640},{10301,320},{2,80000}}},
    [5]={id=4,effect_list={},high=10,low=6,rewards={{10102,480},{10301,240},{2,50000}}},
    [6]={id=4,effect_list={},high=20,low=11,rewards={{10102,320},{10301,160},{2,20000}}}},
 [5] = {
    [1]={id=5,effect_list={50112,34005,10996},high=1,low=1,rewards={{50117,1},{4,888},{11,1200},{10102,600},{2,300000}}},
    [2]={id=5,effect_list={34005,10996},high=2,low=2,rewards={{4,666},{11,1000},{10102,500},{2,200000}}},
    [3]={id=5,effect_list={34005,10996},high=3,low=3,rewards={{4,555},{11,800},{10102,400},{2,100000}}},
    [4]={id=5,effect_list={10996},high=5,low=4,rewards={{11,640},{10102,320},{2,80000}}},
    [5]={id=5,effect_list={10995},high=10,low=6,rewards={{11,480},{10102,240},{2,50000}}},
    [6]={id=5,effect_list={10995},high=20,low=11,rewards={{11,320},{10102,160},{2,20000}}}},
 [6] = {
    [1]={id=6,effect_list={50105,30030},high=1,low=1,rewards={{50104,1},{4,888},{11,1200},{10102,1200},{2,300000}}},
    [2]={id=6,effect_list={30024},high=2,low=2,rewards={{4,666},{11,1000},{10102,1000},{2,200000}}},
    [3]={id=6,effect_list={30024},high=3,low=3,rewards={{4,555},{11,800},{10102,800},{2,100000}}},
    [4]={id=6,effect_list={},high=5,low=4,rewards={{11,640},{10102,640},{2,80000}}},
    [5]={id=6,effect_list={},high=10,low=6,rewards={{11,480},{10102,480},{2,50000}}},
    [6]={id=6,effect_list={},high=20,low=11,rewards={{11,320},{10102,320},{2,20000}}}},
 [7] = {
    [1]={id=7,effect_list={50103,10421,10030},high=1,low=1,rewards={{50111,1},{35113,3},{10030,10},{10008,100},{2,300000}}},
    [2]={id=7,effect_list={10420,10030},high=2,low=2,rewards={{35113,2},{10030,8},{10008,80},{2,200000}}},
    [3]={id=7,effect_list={10420,10030},high=3,low=3,rewards={{35113,1},{10030,6},{10008,60},{2,100000}}},
    [4]={id=7,effect_list={10030},high=5,low=4,rewards={{10030,4},{10008,30},{2,80000}}},
    [5]={id=7,effect_list={10030},high=10,low=6,rewards={{10030,3},{10008,20},{2,50000}}},
    [6]={id=7,effect_list={10030},high=20,low=11,rewards={{10030,2},{10008,10},{2,20000}}}},
 [8] = {
    [1]={id=8,effect_list={50111,30029,10152},high=1,low=1,rewards={{50102,1},{10405,3},{13,50},{7,1200},{2,300000}}},
    [2]={id=8,effect_list={30029,10152},high=2,low=2,rewards={{10405,2},{13,40},{7,1000},{2,200000}}},
    [3]={id=8,effect_list={30029,10152},high=3,low=3,rewards={{10405,1},{13,30},{7,800},{2,100000}}},
    [4]={id=8,effect_list={10152},high=5,low=4,rewards={{13,20},{7,640},{2,80000}}},
    [5]={id=8,effect_list={10151},high=10,low=6,rewards={{13,10},{7,480},{2,50000}}},
    [6]={id=8,effect_list={10151},high=20,low=11,rewards={{13,5},{7,320},{2,20000}}}},
 [9] = {
    [1]={id=9,effect_list={50112,34005,10996},high=1,low=1,rewards={{50108,1},{72003,3},{13,50},{11,1200},{2,300000}}},
    [2]={id=9,effect_list={34005,10996},high=2,low=2,rewards={{72003,2},{13,40},{11,1000},{2,200000}}},
    [3]={id=9,effect_list={34005,10996},high=3,low=3,rewards={{72003,1},{13,30},{11,800},{2,100000}}},
    [4]={id=9,effect_list={10996},high=5,low=4,rewards={{13,20},{11,640},{2,80000}}},
    [5]={id=9,effect_list={10995},high=10,low=6,rewards={{13,10},{11,480},{2,50000}}},
    [6]={id=9,effect_list={10995},high=20,low=11,rewards={{13,5},{11,320},{2,20000}}}},
 [10] = {
    [1]={id=10,effect_list={50113,30030,10412},high=1,low=1,rewards={{50114,1},{10421,1},{10030,10},{10102,600},{2,300000}}},
    [2]={id=10,effect_list={30024,10412},high=2,low=2,rewards={{10420,2},{10030,8},{10102,500},{2,200000}}},
    [3]={id=10,effect_list={30024,10412},high=3,low=3,rewards={{10420,1},{10030,6},{10102,400},{2,100000}}},
    [4]={id=10,effect_list={10412},high=5,low=4,rewards={{10030,4},{10102,320},{2,80000}}},
    [5]={id=10,effect_list={10412},high=10,low=6,rewards={{10030,3},{10102,240},{2,50000}}},
    [6]={id=10,effect_list={10412},high=20,low=11,rewards={{10030,2},{10102,160},{2,20000}}}},
 [11] = {
    [1]={id=11,effect_list={50114,10421,10030},high=1,low=1,rewards={{50101,1},{34001,3},{10152,2},{10008,100},{2,300000}}},
    [2]={id=11,effect_list={10420,10030},high=2,low=2,rewards={{34001,2},{10152,2},{10008,80},{2,200000}}},
    [3]={id=11,effect_list={10420,10030},high=3,low=3,rewards={{34001,1},{10152,1},{10008,60},{2,100000}}},
    [4]={id=11,effect_list={10030},high=5,low=4,rewards={{10152,1},{10008,30},{2,80000}}},
    [5]={id=11,effect_list={10030},high=10,low=6,rewards={{10151,2},{10008,20},{2,50000}}},
    [6]={id=11,effect_list={10030},high=20,low=11,rewards={{10151,1},{10008,10},{2,20000}}}},
 [12] = {
    [1]={id=12,effect_list={50115,34005,13},high=1,low=1,rewards={{50107,1},{10421,1},{10996,3},{7,1200},{2,300000}}},
    [2]={id=12,effect_list={34005,13},high=2,low=2,rewards={{10420,2},{10996,2},{7,1000},{2,200000}}},
    [3]={id=12,effect_list={34005,13},high=3,low=3,rewards={{10420,1},{10996,2},{7,800},{2,100000}}},
    [4]={id=12,effect_list={13},high=5,low=4,rewards={{10996,1},{7,640},{2,80000}}},
    [5]={id=12,effect_list={13},high=10,low=6,rewards={{10995,2},{7,480},{2,50000}}},
    [6]={id=12,effect_list={13},high=20,low=11,rewards={{10995,1},{7,320},{2,20000}}}},
 [13] = {
    [1]={id=13,effect_list={50116,30030},high=1,low=1,rewards={{50106,1},{30030,1},{10412,3},{11,1200},{2,300000}}},
    [2]={id=13,effect_list={30024},high=2,low=2,rewards={{30024,2},{10412,3},{11,1000},{2,200000}}},
    [3]={id=13,effect_list={30024},high=3,low=3,rewards={{30024,1},{10412,2},{11,800},{2,100000}}},
    [4]={id=13,effect_list={},high=5,low=4,rewards={{10412,2},{11,640},{2,80000}}},
    [5]={id=13,effect_list={},high=10,low=6,rewards={{10412,1},{11,480},{2,50000}}},
    [6]={id=13,effect_list={},high=20,low=11,rewards={{10412,1},{11,320},{2,20000}}}},
 [14] = {
    [1]={id=14,effect_list={50117,4},high=1,low=1,rewards={{50117,1},{4,888},{11,1200},{10102,600},{2,300000}}},
    [2]={id=14,effect_list={4},high=2,low=2,rewards={{4,666},{11,1000},{10102,500},{2,200000}}},
    [3]={id=14,effect_list={4},high=3,low=3,rewards={{4,555},{11,800},{10102,400},{2,100000}}},
    [4]={id=14,effect_list={},high=5,low=4,rewards={{11,640},{10102,320},{2,80000}}},
    [5]={id=14,effect_list={},high=10,low=6,rewards={{11,480},{10102,240},{2,50000}}},
    [6]={id=14,effect_list={},high=20,low=11,rewards={{11,320},{10102,160},{2,20000}}}},
 [15] = {
    [1]={id=15,effect_list={50104,4},high=1,low=1,rewards={{50112,1},{72003,3},{72002,4},{72001,30},{2,300000}}},
    [2]={id=15,effect_list={4},high=2,low=2,rewards={{72003,2},{72002,3},{72001,20},{2,200000}}},
    [3]={id=15,effect_list={4},high=3,low=3,rewards={{72003,1},{72002,3},{72001,10},{2,100000}}},
    [4]={id=15,effect_list={},high=5,low=4,rewards={{72002,2},{72001,5},{2,80000}}},
    [5]={id=15,effect_list={},high=10,low=6,rewards={{72002,1},{72001,5},{2,50000}}},
    [6]={id=15,effect_list={},high=20,low=11,rewards={{72002,1},{72001,3},{2,20000}}}},
 [16] = {
    [1]={id=16,effect_list={50111,30029,10152},high=1,low=1,rewards={{50105,1},{30030,1},{10102,1200},{10301,600},{2,300000}}},
    [2]={id=16,effect_list={30029,10152},high=2,low=2,rewards={{30024,2},{10102,1000},{10301,500},{2,200000}}},
    [3]={id=16,effect_list={30029,10152},high=3,low=3,rewards={{30024,1},{10102,800},{10301,400},{2,100000}}},
    [4]={id=16,effect_list={10152},high=5,low=4,rewards={{10102,640},{10301,320},{2,80000}}},
    [5]={id=16,effect_list={10151},high=10,low=6,rewards={{10102,480},{10301,240},{2,50000}}},
    [6]={id=16,effect_list={10151},high=20,low=11,rewards={{10102,320},{10301,160},{2,20000}}}},
 [17] = {
    [1]={id=17,effect_list={50102,10405,13},high=1,low=1,rewards={{50103,1},{10421,1},{10030,10},{8,1200},{2,300000}}},
    [2]={id=17,effect_list={10405,13},high=2,low=2,rewards={{10420,2},{10030,8},{8,1000},{2,200000}}},
    [3]={id=17,effect_list={10405,13},high=3,low=3,rewards={{10420,1},{10030,6},{8,800},{2,100000}}},
    [4]={id=17,effect_list={13},high=5,low=4,rewards={{10030,4},{8,640},{2,80000}}},
    [5]={id=17,effect_list={13},high=10,low=6,rewards={{10030,3},{8,480},{2,50000}}},
    [6]={id=17,effect_list={13},high=20,low=11,rewards={{10030,2},{8,320},{2,20000}}}},
 [18] = {
    [1]={id=18,effect_list={50115,72003,13},high=1,low=1,rewards={{50111,1},{35113,3},{10030,10},{10008,100},{2,300000}}},
    [2]={id=18,effect_list={72003,13},high=2,low=2,rewards={{35113,2},{10030,8},{10008,80},{2,200000}}},
    [3]={id=18,effect_list={72003,13},high=3,low=3,rewards={{35113,1},{10030,6},{10008,60},{2,100000}}},
    [4]={id=18,effect_list={13},high=5,low=4,rewards={{10030,4},{10008,30},{2,80000}}},
    [5]={id=18,effect_list={13},high=10,low=6,rewards={{10030,3},{10008,20},{2,50000}}},
    [6]={id=18,effect_list={13},high=20,low=11,rewards={{10030,2},{10008,10},{2,20000}}}},
 [19] = {
    [1]={id=19,effect_list={50114,10421,10030},high=1,low=1,rewards={{50112,1},{72003,3},{72002,4},{72001,30},{2,300000}}},
    [2]={id=19,effect_list={10420,10030},high=2,low=2,rewards={{72003,2},{72002,3},{72001,20},{2,200000}}},
    [3]={id=19,effect_list={10420,10030},high=3,low=3,rewards={{72003,1},{72002,3},{72001,10},{2,100000}}},
    [4]={id=19,effect_list={10030},high=5,low=4,rewards={{72002,2},{72001,5},{2,80000}}},
    [5]={id=19,effect_list={10030},high=10,low=6,rewards={{72002,1},{72001,5},{2,50000}}},
    [6]={id=19,effect_list={10030},high=20,low=11,rewards={{72002,1},{72001,3},{2,20000}}}}
}
Config.TempDaysRankData.data_rank_data_fun = function(key)
    local data =Config.TempDaysRankData.data_rank_data[key]
    if DATA_DEBUG and data == nil then
        print('( Config.TempDaysRankData.data_rank_data['..key..'])not found') return
    end
    return data
end
---------------------data_rank_data end--------------------
---------------------data_rank_quest_id start--------------------
Config.TempDaysRankData.data_rank_quest_id_length = 24
Config.TempDaysRankData.data_rank_quest_id = {
 [1001] = {id=1001,progress={[1] ={target=10300,param={'chapter'},target_val=1,cli_label="evt_dungeon_pass"}},rewards={{10008,2},{10102,30},{2,20000}},desc="通关第30关",effect_list={},target_desc="达成:%s/1"},
 [1002] = {id=1002,progress={[1] ={target=20180,param={'chapter'},target_val=1,cli_label="evt_dungeon_pass"}},rewards={{10008,4},{10102,60},{2,40000}},desc="通关第60关",effect_list={},target_desc="达成:%s/1"},
 [2001] = {id=2001,progress={[1] ={target=0,param={},target_val=10,cli_label="evt_adventure_explore"}},rewards={{7,300},{10102,30},{1,4000}},desc="探索10个格子",effect_list={},target_desc="达成:%s/10个"},
 [2002] = {id=2002,progress={[1] ={target=0,param={},target_val=20,cli_label="evt_adventure_explore"}},rewards={{7,600},{10102,60},{1,8000}},desc="探索20个格子",effect_list={},target_desc="达成:%s/20个"},
 [3001] = {id=3001,progress={[1] ={target=0,param={{'break_lev',4}},target_val=1,cli_label="evt_partner"}},rewards={{11,500},{10102,30},{2,20000}},desc="1个英雄+4",effect_list={},target_desc="达成:%s/1个"},
 [3002] = {id=3002,progress={[1] ={target=0,param={{'break_lev',4}},target_val=5,cli_label="evt_partner"}},rewards={{11,1000},{10102,60},{2,40000}},desc="5个英雄+4",effect_list={},target_desc="达成:%s/5个"},
 [4001] = {id=4001,progress={[1] ={target=0,param={},target_val=10,cli_label="evt_arena_fight"}},rewards={{8,100},{10102,30},{2,20000}},desc="竞技挑战10次",effect_list={},target_desc="达成:%s/10次"},
 [4002] = {id=4002,progress={[1] ={target=0,param={},target_val=15,cli_label="evt_arena_fight"}},rewards={{8,200},{10102,60},{2,40000}},desc="竞技挑战15次",effect_list={},target_desc="达成:%s/15次"},
 [5001] = {id=5001,progress={[1] ={target=0,param={},target_val=15,cli_label="evt_star_tower_floor_pass"}},rewards={{10102,100},{10301,100},{2,20000}},desc="星命塔15层",effect_list={},target_desc="达成:%s/15层"},
 [5002] = {id=5002,progress={[1] ={target=0,param={},target_val=20,cli_label="evt_star_tower_floor_pass"}},rewards={{10102,200},{10301,200},{2,40000}},desc="星命塔20层",effect_list={},target_desc="达成:%s/20层"},
 [6001] = {id=6001,progress={[1] ={target=0,param={{'lev',5}},target_val=1,cli_label="evt_star_level_up"}},rewards={{10102,250},{10301,100},{2,20000}},desc="星命达到5级",effect_list={},target_desc="达成:%s/1"},
 [6002] = {id=6002,progress={[1] ={target=0,param={{'lev',10}},target_val=1,cli_label="evt_star_level_up"}},rewards={{10102,500},{10301,200},{2,40000}},desc="星命达到10级",effect_list={},target_desc="达成:%s/1"},
 [7001] = {id=7001,progress={[1] ={target=200000,param={'no_show'},target_val=1,cli_label="evt_power"}},rewards={{11,500},{10102,30},{2,20000}},desc="总战力20W",effect_list={},target_desc="达成:%s/1"},
 [7002] = {id=7002,progress={[1] ={target=250000,param={'no_show'},target_val=1,cli_label="evt_power"}},rewards={{11,1000},{10102,60},{2,40000}},desc="总战力25W",effect_list={},target_desc="达成:%s/1"},
 [8001] = {id=8001,progress={[1] ={target=0,param={},target_val=100,cli_label="evt_loss_gold"}},rewards={{7,300},{10102,30},{1,4000}},desc="消费100蓝钻",effect_list={},target_desc="达成:%s/100"},
 [8002] = {id=8002,progress={[1] ={target=0,param={},target_val=300,cli_label="evt_loss_gold"}},rewards={{7,600},{10102,60},{1,8000}},desc="消费300蓝钻",effect_list={},target_desc="达成:%s/300"},
 [9001] = {id=9001,progress={[1] ={target=0,param={},target_val=30,cli_label="evt_loss_hallows_essence"}},rewards={{72001,5},{11,100},{2,20000}},desc="消耗30圣器精华",effect_list={},target_desc="达成:%s/30"},
 [9002] = {id=9002,progress={[1] ={target=0,param={},target_val=60,cli_label="evt_loss_hallows_essence"}},rewards={{72001,10},{11,200},{2,40000}},desc="消耗60圣器精华",effect_list={},target_desc="达成:%s/60"},
 [10001] = {id=10001,progress={[1] ={target=0,param={},target_val=30,cli_label="evt_stone_all_lv"}},rewards={{70003,10},{10102,30},{1,4000}},desc="宝石总等级达到30",effect_list={},target_desc="达成:%s/30"},
 [10002] = {id=10002,progress={[1] ={target=0,param={},target_val=40,cli_label="evt_stone_all_lv"}},rewards={{70003,15},{10102,60},{1,8000}},desc="宝石总等级达到40",effect_list={},target_desc="达成:%s/40"},
 [11001] = {id=11001,progress={[1] ={target=0,param={},target_val=5,cli_label="evt_dial"}},rewards={{7,300},{10102,30},{1,4000}},desc="寻宝5次",effect_list={},target_desc="达成:%s/5次"},
 [11002] = {id=11002,progress={[1] ={target=0,param={},target_val=10,cli_label="evt_dial"}},rewards={{7,600},{10102,60},{1,8000}},desc="寻宝10次",effect_list={},target_desc="达成:%s/10次"},
 [12001] = {id=12001,progress={[1] ={target=55,param={},target_val=1,cli_label="evt_endless_pass"}},rewards={{11,500},{10102,30},{2,20000}},desc="无尽试炼通过55关",effect_list={},target_desc="达成:%s/1"},
 [12002] = {id=12002,progress={[1] ={target=65,param={},target_val=1,cli_label="evt_endless_pass"}},rewards={{11,1000},{10102,60},{2,40000}},desc="无尽试炼通过65关",effect_list={},target_desc="达成:%s/1"}
}
Config.TempDaysRankData.data_rank_quest_id_fun = function(key)
    local data =Config.TempDaysRankData.data_rank_quest_id[key]
    if DATA_DEBUG and data == nil then
        print('( Config.TempDaysRankData.data_rank_quest_id['..key..'])not found') return
    end
    return data
end
---------------------data_rank_quest_id end--------------------
---------------------data_rank_data_const start--------------------
Config.TempDaysRankData.data_rank_data_const_length = 32
Config.TempDaysRankData.data_rank_data_const = {
 ["advanture_limit"] = {desc="神界探索度达到X值以上才能获得第一名奖励",key="advanture_limit",val=1000},
 ["arena_limit"] = {desc="竞技场积分需达到X值以上才能获得第一名奖励",key="arena_limit",val=900},
 ["close_shop_time"] = {desc="关闭图标时间",key="close_shop_time",val={'open_day',7}},
 ["cluster_end_time"] = {desc="跨服榜X天结束",key="cluster_end_time",val={'cluster_day',7,86399}},
 ["cluster_open_time"] = {desc="跨服开启功能时间",key="cluster_open_time",val={{2018,10,26},{0,0,0}}},
 ["dugeon_limit"] = {desc="推图至哪个关卡才能获得第一名奖励",key="dugeon_limit",val=10420},
 ["end_time"] = {desc="X天结束",key="end_time",val={'open_day',12,86399}},
 ["open_time"] = {desc="开启功能时间",key="open_time",val={{2018,2,2},{0,0,0}}},
 ["partner_limit"] = {desc="英雄单个战力打达到X值以上才能获得第一名奖励",key="partner_limit",val=10000},
 ["rank_title1"] = {desc="剧情推图称号ID",key="rank_title1",val=90006},
 ["rank_title10"] = {desc="观星大师称号ID",key="rank_title10",val=90703},
 ["rank_title11"] = {desc="无尽试炼称号ID",key="rank_title11",val=90704},
 ["rank_title12"] = {desc="英雄召唤称号ID",key="rank_title12",val=90705},
 ["rank_title13"] = {desc="最强阵容称号ID",key="rank_title13",val=90706},
 ["rank_title14"] = {desc="消费排行称号ID",key="rank_title14",val=90707},
 ["rank_title15"] = {desc="超神阵容称号ID",key="rank_title15",val=90009},
 ["rank_title16"] = {desc="炫彩宝石称号ID",key="rank_title16",val=90701},
 ["rank_title17"] = {desc="爬塔达人称号ID",key="rank_title17",val=90007},
 ["rank_title18"] = {desc="寻宝专家称号ID",key="rank_title18",val=90013},
 ["rank_title19"] = {desc="无尽试炼称号ID",key="rank_title19",val=90704},
 ["rank_title2"] = {desc="神界冒险称号ID",key="rank_title2",val=90012},
 ["rank_title3"] = {desc="最强英雄称号ID",key="rank_title3",val=90011},
 ["rank_title4"] = {desc="消费排行称号ID",key="rank_title4",val=90707},
 ["rank_title5"] = {desc="圣器比拼称号ID",key="rank_title5",val=90702},
 ["rank_title6"] = {desc="星命之耀称号ID",key="rank_title6",val=90010},
 ["rank_title7"] = {desc="竞技天王称号ID",key="rank_title7",val=90008},
 ["rank_title8"] = {desc="炫彩宝石称号ID",key="rank_title8",val=90701},
 ["rank_title9"] = {desc="圣器比拼称号ID",key="rank_title9",val=90702},
 ["reward_limit"] = {desc="奖励人数",key="reward_limit",val=20},
 ["star_limit"] = {desc="星命总评分达到X值以上才能获得第一名奖励",key="star_limit",val=5000},
 ["team_limit"] = {desc="阵容总战力达到X值以上才能获得第一名奖励",key="team_limit",val=30000},
 ["tower_limit"] = {desc="星命塔需挑战至第X层才能获得第一名奖励",key="tower_limit",val=20}
}
Config.TempDaysRankData.data_rank_data_const_fun = function(key)
    local data =Config.TempDaysRankData.data_rank_data_const[key]
    if DATA_DEBUG and data == nil then
        print('( Config.TempDaysRankData.data_rank_data_const['..key..'])not found') return
    end
    return data
end
---------------------data_rank_data_const end--------------------
---------------------data_rank_quest start--------------------
Config.TempDaysRankData.data_rank_quest_length = 12
Config.TempDaysRankData.data_rank_quest = {
 [1] = {
    [1]={id=1001,rewards={{10008,2},{10102,30},{2,20000}},desc="通关第30关",effect_list={},target_desc="达成:%s/1"},
    [2]={id=1002,rewards={{10008,4},{10102,60},{2,40000}},desc="通关第60关",effect_list={},target_desc="达成:%s/1"}},
 [2] = {
    [1]={id=2001,rewards={{7,300},{10102,30},{1,4000}},desc="探索10个格子",effect_list={},target_desc="达成:%s/30"},
    [2]={id=2002,rewards={{7,600},{10102,60},{1,8000}},desc="探索20个格子",effect_list={},target_desc="达成:%s/40"}},
 [3] = {
    [1]={id=3001,rewards={{11,500},{10102,30},{2,20000}},desc="1个英雄+4",effect_list={},target_desc="达成:%s/15层"},
    [2]={id=3002,rewards={{11,1000},{10102,60},{2,40000}},desc="5个英雄+4",effect_list={},target_desc="达成:%s/20层"}},
 [4] = {
    [1]={id=8001,rewards={{7,300},{10102,30},{1,4000}},desc="消费100蓝钻",effect_list={},target_desc="达成:%s/5次"},
    [2]={id=8002,rewards={{7,600},{10102,60},{1,8000}},desc="消费300蓝钻",effect_list={},target_desc="达成:%s/10次"}},
 [5] = {
    [1]={id=9001,rewards={{72001,5},{11,100},{2,20000}},desc="消耗30圣器精华",effect_list={},target_desc="达成:%s/1"},
    [2]={id=9002,rewards={{72001,10},{11,200},{2,40000}},desc="消耗60圣器精华",effect_list={},target_desc="达成:%s/1"}},
 [6] = {
    [1]={id=6001,rewards={{10102,250},{10301,100},{2,20000}},desc="星命达到5级",effect_list={},target_desc="达成:%s/1"},
    [2]={id=6002,rewards={{10102,500},{10301,200},{2,40000}},desc="星命达到10级",effect_list={},target_desc="达成:%s/1"}},
 [7] = {
    [1]={id=4001,rewards={{8,100},{10102,30},{2,20000}},desc="竞技挑战10次",effect_list={},target_desc="达成:%s/10个"},
    [2]={id=4002,rewards={{8,200},{10102,60},{2,40000}},desc="竞技挑战15次",effect_list={},target_desc="达成:%s/20个"}},
 [15] = {
    [1]={id=7001,rewards={{11,500},{10102,30},{2,20000}},desc="总战力20W",effect_list={},target_desc="达成:%s/1个"},
    [2]={id=7002,rewards={{11,1000},{10102,60},{2,40000}},desc="总战力25W",effect_list={},target_desc="达成:%s/5个"}},
 [16] = {
    [1]={id=10001,rewards={{70003,10},{10102,30},{1,4000}},desc="宝石总等级达到30",effect_list={},target_desc="达成:%s/100"},
    [2]={id=10002,rewards={{70003,15},{10102,60},{1,8000}},desc="宝石总等级达到40",effect_list={},target_desc="达成:%s/300"}},
 [17] = {
    [1]={id=5001,rewards={{10102,100},{10301,100},{2,20000}},desc="星命塔15层",effect_list={},target_desc="达成:%s/30"},
    [2]={id=5002,rewards={{10102,200},{10301,200},{2,40000}},desc="星命塔20层",effect_list={},target_desc="达成:%s/60"}},
 [18] = {
    [1]={id=11001,rewards={{7,300},{10102,30},{1,4000}},desc="寻宝5次",effect_list={},target_desc="达成:%s/1"},
    [2]={id=11002,rewards={{7,600},{10102,60},{1,8000}},desc="寻宝10次",effect_list={},target_desc="达成:%s/1"}},
 [19] = {
    [1]={id=12001,rewards={{11,500},{10102,30},{2,20000}},desc="无尽试炼通过55关",effect_list={},target_desc="达成:%s/10次"},
    [2]={id=12002,rewards={{11,1000},{10102,60},{2,40000}},desc="无尽试炼通过65关",effect_list={},target_desc="达成:%s/15次"}}
}
Config.TempDaysRankData.data_rank_quest_fun = function(key)
    local data =Config.TempDaysRankData.data_rank_quest[key]
    if DATA_DEBUG and data == nil then
        print('( Config.TempDaysRankData.data_rank_quest['..key..'])not found') return
    end
    return data
end
---------------------data_rank_quest end--------------------
