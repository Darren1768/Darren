----------------------------------------------------
-- 此文件由数据工具生成
-- buff配置数据--buff_data.xml
--------------------------------------

Config = Config or {} 
Config.BuffData = Config.BuffData or {}

-- -------------------get_buff_data_start-------------------
Config.BuffData.data_get_buff_data_length = 38
Config.BuffData.data_get_buff_data = {
	[1000] = {bid=1000, name="经验增幅", type="add", group=1000, effect={{'exp',2}}, des="经验获取增加100%", icon=10000, seconds=86400},
	[1010] = {bid=1010, name="金币增幅", type="add", group=1010, effect={{'coin',2}}, des="金币获取增加100%", icon=10010, seconds=86400},
	[1020] = {bid=1020, name="经验增幅", type="add", group=1000, effect={{'exp',2}}, des="经验获取增加100%", icon=10000, seconds=259200},
	[1030] = {bid=1030, name="攻击加成", type="add", group=1030, effect={{'atk_per',50}}, des="攻击增加", icon=10000, seconds=0},
	[1040] = {bid=1040, name="气血加成", type="add", group=1040, effect={{'hp_max_per',100}}, des="气血增加", icon=10001, seconds=0},
	[1050] = {bid=1050, name="伤害加成", type="add", group=1050, effect={{'dam',50}}, des="伤害增加", icon=10002, seconds=0},
	[1060] = {bid=1060, name="免伤加成", type="add", group=1060, effect={{'res',50}}, des="免伤增加", icon=10003, seconds=0},
	[1070] = {bid=1070, name="速度加成", type="add", group=1070, effect={{'speed_per',50}}, des="速度增加", icon=10004, seconds=0},
	[2000] = {bid=2000, name="攻击+10%", type="add", group=2000, effect={{'atk_per',50}}, des="攻击+5%", icon=10000, seconds=0},
	[2010] = {bid=2010, name="攻击+15%", type="add", group=2010, effect={{'atk_per',100}}, des="攻击+10%", icon=10000, seconds=0},
	[2020] = {bid=2020, name="攻击+20%", type="add", group=2010, effect={{'atk_per',150}}, des="攻击+15%", icon=10000, seconds=0},
	[3000] = {bid=3000, name="攻击+10%", type="add", group=3000, effect={{'atk_per',100}}, des="攻击+10%", icon=3020, seconds=3},
	[3020] = {bid=3020, name="气血+10%", type="add", group=3020, effect={{'hp_max_per',100}}, des="气血+10%", icon=3030, seconds=3},
	[3040] = {bid=3040, name="伤害+10%", type="add", group=3040, effect={{'dam',100}}, des="伤害+10%", icon=3040, seconds=3},
	[3060] = {bid=3060, name="免伤+10%", type="add", group=3060, effect={{'res',100}}, des="免伤+10%", icon=3060, seconds=3},
	[3080] = {bid=3080, name="速度+10%", type="add", group=3080, effect={{'speed_per',100}}, des="速度+10%", icon=3070, seconds=3},
	[3100] = {bid=3100, name="金币加成+10% ", type="add", group=3100, effect={{'adv_coin',100}}, des="金币+10% ", icon=3012, seconds=7200},
	[3120] = {bid=3120, name="精炼石加成+20%", type="add", group=3120, effect={{'adv_item_10102',200}}, des="精炼石+20%", icon=3013, seconds=7200},
	[3140] = {bid=3140, name="怪物收益+10%", type="add", group=3140, effect={{'adv_mon',100}}, des="怪物收益+10%", icon=3011, seconds=7200},
	[3160] = {bid=3160, name="采集翻倍+10%", type="add", group=3160, effect={{'adv_effect',100}}, des="采集翻倍概率10%", icon=3010, seconds=7200},
	[3200] = {bid=3200, name="伤害+10%", type="add", group=3200, effect={{'dam',100}}, des="伤害+10%", icon=3040, seconds=600},
	[900101] = {bid=900101, name="暴击+0.5%", type="add", group=900101, effect={{'crit_rate',5}}, des="暴击提升0.5%", icon=3020, seconds=0},
	[900102] = {bid=900102, name="防御+0.5%", type="add", group=900102, effect={{'def_per',5}}, des="防御提升0.5%", icon=3060, seconds=0},
	[900103] = {bid=900103, name="攻击+0.5%", type="add", group=900103, effect={{'atk_per',5}}, des="攻击提升0.5%", icon=3020, seconds=0},
	[900104] = {bid=900104, name="生命+0.5%", type="add", group=900104, effect={{'hp_max_per',5}}, des="生命提升0.5%", icon=3030, seconds=0},
	[900105] = {bid=900105, name="伤害+0.5%", type="add", group=900105, effect={{'dam',5}}, des="伤害提升0.5%", icon=3040, seconds=0},
	[900106] = {bid=900106, name="免伤+0.5%", type="add", group=900106, effect={{'res',5}}, des="免伤提升0.5%", icon=3060, seconds=0},
	[900903] = {bid=900903, name="攻击+10%", type="add", group=900103, effect={{'atk_per',100}}, des="攻击提升10%", icon=3020, seconds=0},
	[900503] = {bid=900503, name="攻击+2%", type="add", group=900503, effect={{'atk_per',20}}, des="攻击提升2%", icon=3020, seconds=0},
	[900513] = {bid=900513, name="攻击+2%", type="add", group=900513, effect={{'atk_per',20}}, des="攻击提升2%", icon=3020, seconds=0},
	[900523] = {bid=900523, name="攻击+3%", type="add", group=900523, effect={{'atk_per',30}}, des="攻击提升3%", icon=3020, seconds=0},
	[900533] = {bid=900533, name="攻击+4%", type="add", group=900533, effect={{'atk_per',40}}, des="攻击提升4%", icon=3020, seconds=0},
	[900543] = {bid=900543, name="攻击+5%", type="add", group=900543, effect={{'atk_per',50}}, des="攻击提升5%", icon=3020, seconds=0},
	[900502] = {bid=900502, name="防御+2%", type="add", group=900502, effect={{'def_per',20}}, des="防御提升2%", icon=3060, seconds=0},
	[900512] = {bid=900512, name="防御+2%", type="add", group=900512, effect={{'def_per',20}}, des="防御提升2%", icon=3060, seconds=0},
	[900522] = {bid=900522, name="防御+3%", type="add", group=900522, effect={{'def_per',30}}, des="防御提升3%", icon=3060, seconds=0},
	[900532] = {bid=900532, name="防御+4%", type="add", group=900532, effect={{'def_per',40}}, des="防御提升4%", icon=3060, seconds=0},
	[900542] = {bid=900542, name="防御+5%", type="add", group=900542, effect={{'def_per',50}}, des="防御提升5%", icon=3060, seconds=0}
}
Config.BuffData.data_get_buff_data_fun = function(key)
	local data=Config.BuffData.data_get_buff_data[key]
	if DATA_DEBUG and data == nil then
		print('(Config.BuffData.data_get_buff_data['..key..'])not found') return
	end
	return data
end
-- -------------------get_buff_data_end---------------------
