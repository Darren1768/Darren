----------------------------------------------------
-- 此文件由数据工具生成
-- 音效配置数据--voice_data.xml
--------------------------------------

Config = Config or {} 
Config.VoiceData = Config.VoiceData or {}

-- -------------------voice_info_start-------------------
Config.VoiceData.data_voice_info_length = 1
Config.VoiceData.data_voice_info = {
	['drama'] = {
		['d_1001'] = {time=6},
		['d_1002'] = {time=3},
		['d_1003'] = {time=3},
		['d_1004'] = {time=2},
		['d_1005'] = {time=1},
		['d_1006'] = {time=2},
		['d_1007'] = {time=3},
		['d_1008'] = {time=2},
		['d_1009'] = {time=3},
		['d_1010'] = {time=3},
		['d_1011'] = {time=2},
		['d_1012'] = {time=2},
		['d_1013'] = {time=2},
		['d_1014'] = {time=2},
		['d_1015'] = {time=1},
		['d_1016'] = {time=3},
		['d_1017'] = {time=2},
		['d_1018'] = {time=3},
		['d_1019'] = {time=3},
		['d_1020'] = {time=5},
		['d_1021'] = {time=3},
		['d_1022'] = {time=3},
		['d_1023'] = {time=3},
		['d_1024'] = {time=2},
		['d_1025'] = {time=3},
	},
}
-- -------------------voice_info_end---------------------
