----------------------------------------------------
-- 此文件由数据工具生成
-- 配置数据--lev_upgrade_data.xml
--------------------------------------

Config = Config or {} 
Config.LevUpgradeData = Config.LevUpgradeData or {}

-- -------------------info_start-------------------
Config.LevUpgradeData.data_info_length = 69
Config.LevUpgradeData.data_info = {
	[70] = {{lev=70, title="剧情副本", desc="继续努力提升等级吧！", status_desc="前往提升", status=0, res_id="8"}
	},
	[69] = {{lev=69, title="剧情副本", desc="继续努力提升等级吧！", status_desc="前往提升", status=0, res_id="8"}
	},
	[68] = {{lev=68, title="剧情副本—第二十一章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"}
	},
	[67] = {{lev=67, title="剧情副本—第二十一章", desc="继续努力提升等级吧！", status_desc="68级开启", status=0, res_id="8"}
	},
	[66] = {{lev=66, title="剧情副本—第二十章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"}
	},
	[65] = {{lev=65, title="剧情副本—第二十章", desc="继续努力提升等级吧！", status_desc="66级开启", status=0, res_id="8"}
	},
	[64] = {{lev=64, title="剧情副本—第十九章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"}
	},
	[63] = {{lev=63, title="剧情副本—第十九章", desc="继续努力提升等级吧！", status_desc="64级开启", status=0, res_id="8"}
	},
	[62] = {{lev=62, title="剧情副本—第十八章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"}
	},
	[61] = {{lev=61, title="剧情副本—第十八章", desc="继续努力提升等级吧！", status_desc="62级开启", status=0, res_id="8"}
	},
	[60] = {{lev=60, title="剧情副本—第十七章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"}
	},
	[59] = {{lev=59, title="剧情副本—第十七章", desc="继续努力提升等级吧！", status_desc="60级开启", status=0, res_id="8"}
	},
	[58] = {{lev=58, title="剧情副本—第十七章", desc="继续努力提升等级吧！", status_desc="60级开启", status=0, res_id="8"}
	},
	[57] = {{lev=57, title="剧情副本—第十七章", desc="继续努力提升等级吧！", status_desc="60级开启", status=0, res_id="8"}
	},
	[56] = {{lev=56, title="剧情副本—第十七章", desc="继续努力提升等级吧！", status_desc="60级开启", status=0, res_id="8"}
	},
	[55] = {{lev=55, title="剧情副本—第十七章", desc="继续努力提升等级吧！", status_desc="60级开启", status=0, res_id="8"}
	},
	[54] = {{lev=54, title="剧情副本—第十五章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"}
	},
	[53] = {{lev=53, title="剧情副本—第十五章", desc="继续努力提升等级吧！", status_desc="54级开启", status=0, res_id="8"}
	},
	[52] = {{lev=52, title="剧情副本—第十五章", desc="继续努力提升等级吧！", status_desc="54级开启", status=0, res_id="8"}
	},
	[51] = {{lev=51, title="剧情副本—第十五章", desc="继续努力提升等级吧！", status_desc="54级开启", status=0, res_id="8"}
	},
	[50] = {{lev=50, title="装备副本—地狱难度", desc="打造独特有个性的英雄！", status_desc="已开启", status=1, res_id="14"},
		{lev=50, title="剧情副本—第十五章", desc="继续努力提升等级吧！", status_desc="54级开启", status=0, res_id="8"}
	},
	[49] = {{lev=49, title="剧情副本—第十三章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"},
		{lev=49, title="装备副本—地狱难度", desc="打造独特有个性的英雄！", status_desc="50级开启", status=0, res_id="14"}
	},
	[48] = {{lev=48, title="剧情副本—第十三章", desc="继续努力提升等级吧！", status_desc="49级开启", status=0, res_id="8"},
		{lev=48, title="装备副本—地狱难度", desc="打造独特有个性的英雄！", status_desc="50级开启", status=0, res_id="14"}
	},
	[47] = {{lev=47, title="剧情副本—第十三章", desc="继续努力提升等级吧！", status_desc="49级开启", status=0, res_id="8"},
		{lev=47, title="装备副本—地狱难度", desc="打造独特有个性的英雄！", status_desc="50级开启", status=0, res_id="14"}
	},
	[46] = {{lev=46, title="剧情副本—第十三章", desc="继续努力提升等级吧！", status_desc="49级开启", status=0, res_id="8"},
		{lev=46, title="装备副本—地狱难度", desc="打造独特有个性的英雄！", status_desc="50级开启", status=0, res_id="14"}
	},
	[45] = {{lev=45, title="装备副本—死亡禁地", desc="追求更强的装备吧！", status_desc="已开启", status=1, res_id="14"},
		{lev=45, title="剧情副本—第十一章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"}
	},
	[44] = {{lev=44, title="装备副本—死亡禁地", desc="追求更强的装备吧！", status_desc="45级开启", status=0, res_id="14"},
		{lev=44, title="剧情副本—第十一章", desc="继续努力提升等级吧！", status_desc="45级开启", status=0, res_id="8"}
	},
	[43] = {{lev=43, title="装备副本—死亡禁地", desc="追求更强的装备吧！", status_desc="45级开启", status=0, res_id="14"},
		{lev=43, title="剧情副本—第十一章", desc="继续努力提升等级吧！", status_desc="45级开启", status=0, res_id="8"}
	},
	[42] = {{lev=42, title="装备副本—死亡禁地", desc="追求更强的装备吧！", status_desc="45级开启", status=0, res_id="14"},
		{lev=42, title="剧情副本—第十一章", desc="继续努力提升等级吧！", status_desc="45级开启", status=0, res_id="8"}
	},
	[41] = {{lev=41, title="剧情副本—第十章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"},
		{lev=41, title="装备副本—死亡禁地", desc="追求更强的装备吧！", status_desc="45级开启", status=0, res_id="14"}
	},
	[40] = {{lev=40, title="星宫助阵", desc="英雄助阵，大幅提升英雄属性！", status_desc="已开启", status=1, res_id="16"},
		{lev=40, title="装备副本—噩梦难度", desc="追求更强的装备吧！", status_desc="已开启", status=1, res_id="14"}
	},
	[39] = {{lev=39, title="星宫助阵", desc="英雄助阵，大幅提升英雄属性！", status_desc="40级开启", status=0, res_id="16"},
		{lev=39, title="装备副本—噩梦难度", desc="追求更强的装备吧！", status_desc="40级开启", status=0, res_id="14"}
	},
	[38] = {{lev=38, title="星宫助阵", desc="英雄助阵，大幅提升英雄属性！", status_desc="40级开启", status=0, res_id="16"},
		{lev=38, title="装备副本—噩梦难度", desc="追求更强的装备吧！", status_desc="40级开启", status=0, res_id="14"}
	},
	[37] = {{lev=37, title="剧情副本—第九章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"},
		{lev=37, title="星宫助阵", desc="英雄助阵，大幅提升英雄属性！", status_desc="40级开启", status=0, res_id="16"}
	},
	[36] = {{lev=36, title="剧情副本—第九章", desc="继续努力提升等级吧！", status_desc="37级开启", status=0, res_id="8"},
		{lev=36, title="星宫助阵", desc="英雄助阵，大幅提升英雄属性！", status_desc="40级开启", status=0, res_id="16"}
	},
	[35] = {{lev=35, title="装备副本—诸神黄昏", desc="打造独特有个性的英雄！", status_desc="已开启", status=1, res_id="14"},
		{lev=35, title="剧情副本—第九章", desc="继续努力提升等级吧！", status_desc="37级开启", status=0, res_id="8"},
		{lev=35, title="星宫助阵", desc="英雄助阵，大幅提升英雄属性！", status_desc="40级开启", status=0, res_id="16"}
	},
	[34] = {{lev=34, title="装备副本—诸神黄昏", desc="打造独特有个性的英雄！", status_desc="35级开启", status=0, res_id="14"},
		{lev=34, title="剧情副本—第九章", desc="继续努力提升等级吧！", status_desc="37级开启", status=0, res_id="8"}
	},
	[33] = {{lev=33, title="剧情副本—第八章", desc="继续努力提升等级吧！", status_desc="已开启", status=1, res_id="8"},
		{lev=33, title="装备副本—诸神黄昏", desc="打造独特有个性的英雄！", status_desc="35级开启", status=0, res_id="14"}
	},
	[32] = {{lev=32, title="异界裂缝", desc="装备洗炼石，转换重置装备新属性", status_desc="已开启", status=1, res_id="17"},
		{lev=32, title="剧情副本—第八章", desc="继续努力提升等级吧！", status_desc="33级开启", status=0, res_id="8"}
	},
	[31] = {{lev=31, title="异界裂缝", desc="装备洗炼石，转换重置装备新属性", status_desc="32级开启", status=0, res_id="17"},
		{lev=31, title="剧情副本—第八章", desc="继续努力提升等级吧！", status_desc="33级开启", status=0, res_id="8"}
	},
	[30] = {{lev=30, title="异界裂缝", desc="装备洗炼石，转换重置装备新属性", status_desc="32级开启", status=0, res_id="17"},
		{lev=30, title="剧情副本—第八章", desc="继续努力提升等级吧！", status_desc="33级开启", status=0, res_id="8"},
		{lev=30, title="装备副本—诸神黄昏", desc="打造独特有个性的英雄！", status_desc="35级开启", status=0, res_id="14"}
	},
	[29] = {{lev=29, title="剧情副本—第八章", desc="继续努力提升等级吧！", status_desc="33级开启", status=0, res_id="8"},
		{lev=29, title="异界裂缝", desc="装备洗炼石，转换重置装备新属性", status_desc="32级开启", status=0, res_id="17"},
		{lev=29, title="剧情副本—第八章", desc="继续努力提升等级吧！", status_desc="33级开启", status=0, res_id="8"}
	},
	[28] = {{lev=28, title="诸神大陆", desc="打boss，抢领地，争霸主", status_desc="已开启", status=1, res_id="15"},
		{lev=28, title="异界裂缝", desc="装备洗炼石，转换重置装备新属性", status_desc="32级开启", status=0, res_id="17"},
		{lev=28, title="剧情副本—第八章", desc="继续努力提升等级吧！", status_desc="33级开启", status=0, res_id="8"},
		{lev=28, title="异界裂缝", desc="装备洗炼石，转换重置装备新属性", status_desc="32级开启", status=0, res_id="17"}
	},
	[27] = {{lev=27, title="诸神大陆", desc="打boss，抢领地，争霸主", status_desc="28级开启", status=0, res_id="15"},
		{lev=27, title="异界裂缝", desc="装备洗炼石，转换重置装备新属性", status_desc="32级开启", status=0, res_id="17"}
	},
	[26] = {{lev=26, title="远征", desc="英雄，胜利在等着你", status_desc="已开启", status=1, res_id="13"},
		{lev=26, title="诸神大陆", desc="打boss，抢领地，争霸主", status_desc="28级开启", status=0, res_id="15"},
		{lev=26, title="异界裂缝", desc="装备洗炼石，转换重置装备新属性", status_desc="32级开启", status=0, res_id="17"}
	},
	[25] = {{lev=25, title="段位赛", desc="高手林立，谁将是霸主？", status_desc="已开启", status=1, res_id="3"},
		{lev=25, title="远征", desc="英雄，胜利在等着你", status_desc="26级开启", status=0, res_id="13"},
		{lev=25, title="诸神大陆", desc="打boss，抢领地，争霸主", status_desc="28级开启", status=0, res_id="15"}
	},
	[24] = {{lev=24, title="段位赛", desc="高手林立，谁将是霸主？", status_desc="25级开启", status=0, res_id="3"},
		{lev=24, title="远征", desc="英雄，胜利在等着你", status_desc="26级开启", status=0, res_id="13"}
	},
	[23] = {{lev=23, title="段位赛", desc="高手林立，谁将是霸主？", status_desc="25级开启", status=0, res_id="3"},
		{lev=23, title="远征", desc="英雄，胜利在等着你", status_desc="26级开启", status=0, res_id="13"}
	},
	[22] = {{lev=22, title="装备副本—黑暗主宰", desc="打造属于你的独特英雄", status_desc="已开启", status=1, res_id="14"},
		{lev=22, title="段位赛", desc="高手林立，谁将是霸主？", status_desc="25级开启", status=0, res_id="3"},
		{lev=22, title="远征", desc="英雄，胜利在等着你", status_desc="26级开启", status=0, res_id="13"}
	},
	[21] = {{lev=21, title="装备副本—黑暗主宰", desc="打造属于你的独特英雄", status_desc="22级开启", status=0, res_id="14"},
		{lev=21, title="段位赛", desc="高手林立，谁将是霸主？", status_desc="25级开启", status=0, res_id="3"}
	},
	[20] = {{lev=20, title="巨龙巢穴", desc="远古巨龙的秘密，等你探索", status_desc="已开启", status=1, res_id="5"},
		{lev=20, title="装备副本—黑暗主宰", desc="打造属于你的独特英雄", status_desc="22级开启", status=0, res_id="14"}
	},
	[19] = {{lev=19, title="巨龙巢穴", desc="远古巨龙的秘密，等你探索", status_desc="20级开启", status=0, res_id="5"},
		{lev=19, title="装备副本—黑暗主宰", desc="打造属于你的独特英雄", status_desc="22级开启", status=0, res_id="14"}
	},
	[18] = {{lev=18, title="凤凰神殿", desc="不灭的凤凰，你能打赢我吗？", status_desc="已开启", status=1, res_id="11"},
		{lev=18, title="巨龙巢穴", desc="远古巨龙的秘密，等你探索", status_desc="20级开启", status=0, res_id="5"}
	},
	[17] = {{lev=17, title="帮会", desc="兄弟，一起跟我们战斗吧", status_desc="已开启", status=1, res_id="3"},
		{lev=17, title="凤凰神殿", desc="不灭的凤凰，你能打赢我吗？", status_desc="18级开启", status=0, res_id="11"}
	},
	[16] = {{lev=16, title="商城系统", desc="奇珍异宝，等你来拿", status_desc="已开启", status=1, res_id="6"},
		{lev=16, title="帮会", desc="兄弟，一起跟我们战斗吧", status_desc="17级开启", status=0, res_id="3"},
		{lev=16, title="凤凰神殿", desc="不灭的凤凰，你能打赢我吗？", status_desc="18级开启", status=0, res_id="11"}
	},
	[15] = {{lev=15, title="试炼塔", desc="你想知道塔顶的秘密吗？", status_desc="已开启", status=1, res_id="10"},
		{lev=15, title="商城系统", desc="奇珍异宝，等你来拿", status_desc="16级开启", status=0, res_id="6"},
		{lev=15, title="帮会", desc="兄弟，一起跟我们战斗吧", status_desc="17级开启", status=0, res_id="3"}
	},
	[14] = {{lev=14, title="炼金场", desc="生产金币和英雄经验，还能兑换资源", status_desc="已开启", status=1, res_id="7"},
		{lev=14, title="试炼塔", desc="你想知道塔顶的秘密吗？", status_desc="15级开启", status=0, res_id="10"}
	},
	[13] = {{lev=13, title="港口", desc="港口贸易的繁荣，能带来财富", status_desc="已开启", status=1, res_id="9"},
		{lev=13, title="炼金场", desc="生产金币和英雄经验，还能兑换资源", status_desc="14级开启", status=0, res_id="7"},
		{lev=13, title="试炼塔", desc="你想知道塔顶的秘密吗？", status_desc="15级开启", status=0, res_id="10"}
	},
	[12] = {{lev=12, title="港口", desc="港口贸易的繁荣，能带来财富", status_desc="13级开启", status=0, res_id="9"},
		{lev=12, title="炼金场", desc="生产金币和英雄经验，还能兑换资源", status_desc="14级开启", status=0, res_id="7"}
	},
	[11] = {{lev=11, title="日常任务", desc="每天做任务，奖励送不停", status_desc="已开启", status=1, res_id="8"},
		{lev=11, title="港口", desc="港口贸易的繁荣，能带来财富", status_desc="13级开启", status=0, res_id="9"},
		{lev=11, title="炼金场", desc="生产金币和英雄经验，还能兑换资源", status_desc="14级开启", status=0, res_id="7"}
	},
	[10] = {{lev=10, title="竞技场", desc="高手对决，争夺荣誉", status_desc="已开启", status=1, res_id="4"},
		{lev=10, title="日常任务", desc="每天做任务，奖励送不停", status_desc="11级开启", status=0, res_id="8"}
	},
	[9] = {{lev=9, title="上阵4个位置", desc="开放第4个上阵位置", status_desc="已开启", status=1, res_id="2"},
		{lev=9, title="竞技场", desc="高手对决，争夺荣誉", status_desc="10级开启", status=0, res_id="4"},
		{lev=9, title="日常任务", desc="每天做任务，奖励送不停", status_desc="11级开启", status=0, res_id="8"}
	},
	[8] = {{lev=8, title="上阵4个位置", desc="开放第4个上阵位置", status_desc="9级开启", status=0, res_id="2"},
		{lev=8, title="竞技场", desc="高手对决，争夺荣誉", status_desc="10级开启", status=0, res_id="4"}
	},
	[7] = {{lev=7, title="上阵4个位置", desc="开放第4个上阵位置", status_desc="9级开启", status=0, res_id="2"},
		{lev=7, title="竞技场", desc="高手对决，争夺荣誉", status_desc="10级开启", status=0, res_id="4"}
	},
	[6] = {{lev=6, title="许愿池", desc="心诚则灵，许愿获得好物品", status_desc="已开启", status=1, res_id="12"},
		{lev=6, title="开服狂欢", desc="一连串狂欢任务等着你", status_desc="已开启", status=1, res_id="6"},
		{lev=6, title="上阵4个位置", desc="开放第4个上阵位置", status_desc="9级开启", status=0, res_id="2"}
	},
	[5] = {{lev=5, title="许愿池", desc="心诚则灵，许愿获得好物品", status_desc="6级开启", status=0, res_id="12"},
		{lev=5, title="开服狂欢", desc="一连串狂欢任务等着你", status_desc="6级开启", status=0, res_id="6"}
	},
	[4] = {{lev=4, title="上阵3个位置", desc="开放第3个上阵位置", status_desc="已开启", status=1, res_id="2"},
		{lev=4, title="许愿池", desc="心诚则灵，许愿获得好物品", status_desc="6级开启", status=0, res_id="12"}
	},
	[3] = {{lev=3, title="上阵3个位置", desc="开放第3个上阵位置", status_desc="4级开启", status=0, res_id="2"},
		{lev=3, title="许愿池", desc="心诚则灵，许愿获得好物品", status_desc="6级开启", status=0, res_id="12"}
	},
	[2] = {{lev=2, title="上阵3个位置", desc="开放第3个上阵位置", status_desc="4级开启", status=0, res_id="2"},
		{lev=2, title="许愿池", desc="心诚则灵，许愿获得好物品", status_desc="6级开启", status=0, res_id="12"}
	},
}
-- -------------------info_end---------------------
