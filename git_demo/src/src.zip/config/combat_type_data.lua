----------------------------------------------------
-- 此文件由数据工具生成
-- 战斗类型配置数据--combat_type_data.xml
--------------------------------------

Config = Config or {} 
Config.CombatTypeData = Config.CombatTypeData or {}

-- -------------------fight_list_start-------------------
Config.CombatTypeData.data_fight_list_length = 48
Config.CombatTypeData.data_fight_list = {
	[1] = {type=1, des="测试战斗", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=30, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[2] = {type=2, des="竞技场", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="false", max_time=600, max_action_count=20, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=1, from={{1}}},
	[3] = {type=3, des="剧情副本", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[4] = {type=4, des="BOSS", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=20, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[5] = {type=5, des="世界BOSS", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=10, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip="true", start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[6] = {type=6, des="神界冒险", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip="true", start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[7] = {type=7, des="星命塔", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[8] = {type=8, des="切磋", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=30, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=1, from={}},
	[9] = {type=9, des="公会副本", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=5, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[10] = {type=10, des="冠军赛", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=30, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=1, from={{6}}},
	[11] = {type=11, des="无尽试炼", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="false", max_time=0, max_action_count=10, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[12] = {type=12, des="活动BOSS", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=10, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip="true", start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[13] = {type=13, des="萌兽夺宝", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=10, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[14] = {type=14, des="宝石副本", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=10, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[15] = {type=15, des="众神战场", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=30, is_pvp=1, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[16] = {type=16, des="公会战", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=20, is_pvp=1, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=1, from={}},
	[17] = {type=17, des="星河神殿", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=10, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[18] = {type=18, des="跨服天梯", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=20, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=1, from={{9}}},
	[19] = {type=19, des="金币副本", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=10, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[20] = {type=20, des="英雄碎片副本", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=10, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[21] = {type=21, des="英雄远征", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[22] = {type=22, des="元宵活动BOSS", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[23] = {type=23, des="精英段位赛_常规赛", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=1, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=1, from={{93}}},
	[24] = {type=24, des="精英段位赛_王者赛", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=1, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=1, from={{99}}},
	[25] = {type=25, des="元素神殿", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip="true", start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[26] = {type=26, des="英雄试玩", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[27] = {type=27, des="天界副本", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[28] = {type=28, des="跨服竞技场", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=1, from={{19,20}}},
	[29] = {type=29, des="试炼之境", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=10, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[30] = {type=30, des="秘矿争夺", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[31] = {type=31, des="周冠军赛", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=30, is_pvp=1, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=1, from={{6}}},
	[32] = {type=32, des="开学季_关卡", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=8, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[33] = {type=33, des="开学季_boss", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=5, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[34] = {type=34, des="公会秘境", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=20, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}},
	[35] = {type=35, des="组队竞技场", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=30, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=1, from={{28}}},
	[36] = {type=36, des="新手训练营", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[37] = {type=37, des="巅峰冠军赛", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=30, is_pvp=1, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=1, from={{95}}},
	[38] = {type=38, des="旧位面战斗（弃用）", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=20, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[39] = {type=39, des="新年活动战斗", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[40] = {type=40, des="位面战斗", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=20, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[41] = {type=41, des="活力大作战", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=12, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[42] = {type=42, des="协力段位赛", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=1, from={{38}}},
	[43] = {type=43, des="武神殿", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=8, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip=0, start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[101] = {type=101, des="万圣节大富翁第1场景", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[102] = {type=102, des="万圣节大富翁第2场景", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[103] = {type=103, des="万圣节大富翁第3场景", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[104] = {type=104, des="万圣节大富翁第4场景", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=15, is_pvp=0, action_time=0, is_use_balance_mode=2, need_enter_combat=0, is_skip="true", start_effect="E51147", per_speed=0, is_guild_pvp=0, from={}},
	[105] = {type=105, des="万圣节Boss战", can_revive="false", max_partner_num=5, revive_count=0, can_add_hp="true", max_time=0, max_action_count=10, is_pvp=0, action_time=0, is_use_balance_mode=0, need_enter_combat=0, is_skip="true", start_effect="E51145", per_speed=0, is_guild_pvp=0, from={}}
}
Config.CombatTypeData.data_fight_list_fun = function(key)
	local data=Config.CombatTypeData.data_fight_list[key]
	if DATA_DEBUG and data == nil then
		print('(Config.CombatTypeData.data_fight_list['..key..'])not found') return
	end
	return data
end
-- -------------------fight_list_end---------------------


-- -------------------blance_fight_mode_start-------------------
Config.CombatTypeData.data_blance_fight_mode_length = 3
Config.CombatTypeData.data_blance_fight_mode = {
	[3] = {
		[8] = {{type=3, action_count=8, desc="全体被治疗效果-70%,伤害+100%"}
		},
		[7] = {{type=3, action_count=7, desc="全体被治疗效果-60%,伤害+80%"}
		},
		[6] = {{type=3, action_count=6, desc="全体被治疗效果-50%,伤害+60%"}
		},
		[5] = {{type=3, action_count=5, desc="全体被治疗效果-40%,伤害+40%"}
		},
		[4] = {{type=3, action_count=4, desc="全体被治疗效果-30%,伤害+30%"}
		},
		[3] = {{type=3, action_count=3, desc="全体被治疗效果-20%,伤害+20%"}
		},
		[2] = {{type=3, action_count=2, desc="全体被治疗效果-10%,伤害+10%"}
		},
		[1] = {{type=3, action_count=1, desc="全体被治疗效果-10%"}
		},
	},
	[2] = {
		[30] = {{type=2, action_count=30, desc="天平模式开启，全体免伤和受疗-100%"}
		},
		[29] = {{type=2, action_count=29, desc="天平模式开启，全体免伤和受疗-95%"}
		},
		[28] = {{type=2, action_count=28, desc="天平模式开启，全体免伤和受疗-90%"}
		},
		[27] = {{type=2, action_count=27, desc="天平模式开启，全体免伤和受疗-85%"}
		},
		[26] = {{type=2, action_count=26, desc="天平模式开启，全体免伤和受疗-80%"}
		},
		[25] = {{type=2, action_count=25, desc="天平模式开启，全体免伤和受疗-75%"}
		},
		[24] = {{type=2, action_count=24, desc="天平模式开启，全体免伤和受疗-70%"}
		},
		[23] = {{type=2, action_count=23, desc="天平模式开启，全体免伤和受疗-65%"}
		},
		[22] = {{type=2, action_count=22, desc="天平模式开启，全体免伤和受疗-60%"}
		},
		[21] = {{type=2, action_count=21, desc="天平模式开启，全体免伤和受疗-55%"}
		},
		[20] = {{type=2, action_count=20, desc="天平模式开启，全体免伤和受疗-50%"}
		},
		[19] = {{type=2, action_count=19, desc="天平模式开启，全体免伤和受疗-45%"}
		},
		[18] = {{type=2, action_count=18, desc="天平模式开启，全体免伤和受疗-40%"}
		},
		[17] = {{type=2, action_count=17, desc="天平模式开启，全体免伤和受疗-35%"}
		},
		[16] = {{type=2, action_count=16, desc="天平模式开启，全体免伤和受疗-30%"}
		},
		[15] = {{type=2, action_count=15, desc="天平模式开启，全体免伤和受疗-25%"}
		},
		[14] = {{type=2, action_count=14, desc="天平模式开启，全体免伤和受疗-20%"}
		},
		[13] = {{type=2, action_count=13, desc="天平模式开启，全体免伤和受疗-15%"}
		},
		[12] = {{type=2, action_count=12, desc="天平模式开启，全体免伤和受疗-10%"}
		},
		[11] = {{type=2, action_count=11, desc="天平模式开启，全体免伤和受疗-5%"}
		},
	},
	[1] = {
		[30] = {{type=1, action_count=30, desc="天平模式开启，全体伤害+80%"}
		},
		[29] = {{type=1, action_count=29, desc="天平模式开启，全体伤害+75%"}
		},
		[28] = {{type=1, action_count=28, desc="天平模式开启，全体伤害+70%"}
		},
		[27] = {{type=1, action_count=27, desc="天平模式开启，全体伤害+65%"}
		},
		[26] = {{type=1, action_count=26, desc="天平模式开启，全体伤害+60%"}
		},
		[25] = {{type=1, action_count=25, desc="天平模式开启，全体伤害+55%"}
		},
		[24] = {{type=1, action_count=24, desc="天平模式开启，全体伤害+50%"}
		},
		[23] = {{type=1, action_count=23, desc="天平模式开启，全体伤害+45%"}
		},
		[22] = {{type=1, action_count=22, desc="天平模式开启，全体伤害+40%"}
		},
		[21] = {{type=1, action_count=21, desc="天平模式开启，全体伤害+35%"}
		},
		[20] = {{type=1, action_count=20, desc="天平模式开启，全体伤害+30%"}
		},
		[19] = {{type=1, action_count=19, desc="天平模式开启，全体伤害+27%"}
		},
		[18] = {{type=1, action_count=18, desc="天平模式开启，全体伤害+24%"}
		},
		[17] = {{type=1, action_count=17, desc="天平模式开启，全体伤害+21%"}
		},
		[16] = {{type=1, action_count=16, desc="天平模式开启，全体伤害+18%"}
		},
		[15] = {{type=1, action_count=15, desc="天平模式开启，全体伤害+15%"}
		},
		[14] = {{type=1, action_count=14, desc="天平模式开启，全体伤害+12%"}
		},
		[13] = {{type=1, action_count=13, desc="天平模式开启，全体伤害+9%"}
		},
		[12] = {{type=1, action_count=12, desc="天平模式开启，全体伤害+6%"}
		},
		[11] = {{type=1, action_count=11, desc="天平模式开启，全体伤害+3%"}
		},
	},
}
-- -------------------blance_fight_mode_end---------------------


-- -------------------const_start-------------------
Config.CombatTypeData.data_const_length = 2
Config.CombatTypeData.data_const = {
	["pk_agree_timeout"] = {key="pk_agree_timeout", val=180, desc="切磋请求超时时间"},
	["pk_req_timeout"] = {key="pk_req_timeout", val=180, desc="发出切磋冷却时间"}
}
Config.CombatTypeData.data_const_fun = function(key)
	local data=Config.CombatTypeData.data_const[key]
	if DATA_DEBUG and data == nil then
		print('(Config.CombatTypeData.data_const['..key..'])not found') return
	end
	return data
end
-- -------------------const_end---------------------


-- -------------------combat_speed_start-------------------
Config.CombatTypeData.data_combat_speed_length = 3
Config.CombatTypeData.data_combat_speed = {
	[1] = {speed=1, limit_lev=1, limit_vip_lev=0},
	[2] = {speed=2, limit_lev=20, limit_vip_lev=1},
	[3] = {speed=3, limit_lev=100, limit_vip_lev=99}
}
Config.CombatTypeData.data_combat_speed_fun = function(key)
	local data=Config.CombatTypeData.data_combat_speed[key]
	if DATA_DEBUG and data == nil then
		print('(Config.CombatTypeData.data_combat_speed['..key..'])not found') return
	end
	return data
end
-- -------------------combat_speed_end---------------------
