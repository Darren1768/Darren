----------------------------------------------------
-- 此文件由数据工具生成
-- 配置数据--battle_bg_data.xml
--------------------------------------

Config = Config or {} 
Config.BattleBgData = Config.BattleBgData or {}

-- -------------------info_start-------------------
Config.BattleBgData.data_info_length = 48
Config.BattleBgData.data_info = {
	[0] = {bid=10005, bg_music="b_001", is_single_bg=0},
	[1] = {bid=10010, bg_music="b_001", is_single_bg=1},
	[2] = {bid=10005, bg_music="b_003", is_single_bg=1},
	[4] = {bid=10007, bg_music="b_004", is_single_bg=1},
	[5] = {bid=10007, bg_music="b_004", is_single_bg=1},
	[6] = {bid=10014, bg_music="b_004", is_single_bg=1},
	[7] = {bid=10009, bg_music="b_004", is_single_bg=1},
	[8] = {bid=10005, bg_music="b_004", is_single_bg=1},
	[9] = {bid=10007, bg_music="b_002", is_single_bg=1},
	[10] = {bid=10010, bg_music="b_003", is_single_bg=1},
	[11] = {bid=10011, bg_music="b_004", is_single_bg=1},
	[12] = {bid=10009, bg_music="b_004", is_single_bg=1},
	[13] = {bid=10012, bg_music="b_001", is_single_bg=1},
	[14] = {bid=10007, bg_music="b_001", is_single_bg=1},
	[15] = {bid=10013, bg_music="b_003", is_single_bg=1},
	[16] = {bid=10007, bg_music="b_004", is_single_bg=1},
	[17] = {bid=10009, bg_music="b_004", is_single_bg=1},
	[18] = {bid=10016, bg_music="b_004", is_single_bg=1},
	[19] = {bid=10007, bg_music="b_001", is_single_bg=1},
	[20] = {bid=10007, bg_music="b_001", is_single_bg=1},
	[21] = {bid=10015, bg_music="b_004", is_single_bg=1},
	[22] = {bid=10014, bg_music="b_004", is_single_bg=1},
	[23] = {bid=10017, bg_music="b_004", is_single_bg=1},
	[24] = {bid=10017, bg_music="b_004", is_single_bg=1},
	[25] = {bid=10025, bg_music="b_004", is_single_bg=1},
	[26] = {bid=10014, bg_music="b_004", is_single_bg=1},
	[27] = {bid=10013, bg_music="b_004", is_single_bg=1},
	[28] = {bid=10027, bg_music="b_004", is_single_bg=1},
	[29] = {bid=10005, bg_music="b_004", is_single_bg=1},
	[30] = {bid=10028, bg_music="b_004", is_single_bg=1},
	[31] = {bid=10029, bg_music="b_004", is_single_bg=1},
	[32] = {bid=10027, bg_music="b_004", is_single_bg=1},
	[33] = {bid=10030, bg_music="b_004", is_single_bg=1},
	[34] = {bid=10031, bg_music="b_004", is_single_bg=1},
	[35] = {bid=10032, bg_music="b_004", is_single_bg=1},
	[36] = {bid=10030, bg_music="b_004", is_single_bg=1},
	[37] = {bid=10034, bg_music="b_004", is_single_bg=1},
	[38] = {bid=11001, bg_music="b_004", is_single_bg=1},
	[39] = {bid=10035, bg_music="b_004", is_single_bg=1},
	[40] = {bid=11005, bg_music="b_004", is_single_bg=1},
	[41] = {bid=10030, bg_music="b_004", is_single_bg=1},
	[42] = {bid=11006, bg_music="b_004", is_single_bg=1},
	[43] = {bid=11007, bg_music="b_004", is_single_bg=1},
	[101] = {bid=10033, bg_music="b_004", is_single_bg=1},
	[102] = {bid=10033, bg_music="b_004", is_single_bg=1},
	[103] = {bid=10033, bg_music="b_004", is_single_bg=1},
	[104] = {bid=10033, bg_music="b_004", is_single_bg=1},
	[105] = {bid=10033, bg_music="b_004", is_single_bg=1},
}
-- -------------------info_end---------------------


-- -------------------info2_start-------------------
Config.BattleBgData.data_info2_length = 1
Config.BattleBgData.data_info2 = {
	[3] = {
		[10002] = {bid=10002, bg_music="b_002", is_single_bg=0, fornt_effect="E54506", bg_effect="E54507"},
		[10003] = {bid=10003, bg_music="b_001", is_single_bg=0, fornt_effect="", bg_effect=""},
		[10006] = {bid=10006, bg_music="b_002", is_single_bg=0, fornt_effect="E54502", bg_effect="E54503"},
		[10008] = {bid=10008, bg_music="b_001", is_single_bg=0, fornt_effect="", bg_effect=""},
		[10004] = {bid=10004, bg_music="b_001", is_single_bg=0, fornt_effect="", bg_effect=""},
	},
}
-- -------------------info2_end---------------------


-- -------------------fight_name_start-------------------
Config.BattleBgData.data_fight_name_length = 53
Config.BattleBgData.data_fight_name = {
	[0] = "",
	[1] = "",
	[2] = "竞技场",
	[3] = "剧情副本",
	[3] = "剧情副本",
	[3] = "剧情副本",
	[3] = "剧情副本",
	[3] = "剧情副本",
	[4] = "个人boss",
	[5] = "世界boss",
	[6] = "神界探险",
	[7] = "试练塔",
	[8] = "切磋",
	[9] = "公会副本",
	[10] = "竞技场冠军赛",
	[11] = "无尽试炼",
	[12] = "沙滩保卫战",
	[13] = "萌兽夺宝",
	[14] = "日常副本",
	[15] = "众神战场",
	[16] = "公会战",
	[17] = "星河神殿",
	[18] = "跨服天梯",
	[19] = "金币副本",
	[20] = "英雄碎片副本",
	[21] = "英雄远征",
	[22] = "活动BOSS",
	[23] = "精英段位赛_常规赛",
	[24] = "精英段位赛_王者赛",
	[25] = "元素圣殿",
	[26] = "英雄预览",
	[27] = "天界副本",
	[28] = "跨服竞技场",
	[29] = "试炼之境",
	[30] = "秘矿争夺",
	[31] = "周冠军赛",
	[32] = "开学季·关卡",
	[33] = "开学季·boss",
	[34] = "公会秘境",
	[35] = "组队竞技场",
	[36] = "新手训练营",
	[37] = "巅峰冠军赛",
	[38] = "位面征战",
	[39] = "新年活动",
	[40] = "位面征战",
	[41] = "火灵庇佑",
	[42] = "协力段位赛",
	[43] = "武神殿",
	[101] = "万圣节大富翁第1场景",
	[102] = "万圣节大富翁第2场景",
	[103] = "万圣节大富翁第3场景",
	[104] = "万圣节大富翁第4场景",
	[105] = "万圣节Boss战"
}
Config.BattleBgData.data_fight_name_fun = function(key)
	local data=Config.BattleBgData.data_fight_name[key]
	if DATA_DEBUG and data == nil then
		print('(Config.BattleBgData.data_fight_name['..key..'])not found') return
	end
	return data
end
-- -------------------fight_name_end---------------------


-- -------------------back_limit_start-------------------
Config.BattleBgData.data_back_limit_length = 49
Config.BattleBgData.data_back_limit = {
	[0] = 0,
	[1] = 0,
	[2] = 0,
	[3] = 90,
	[4] = 0,
	[5] = 0,
	[6] = 0,
	[7] = 999,
	[8] = 0,
	[9] = 0,
	[10] = 0,
	[11] = 0,
	[12] = 0,
	[13] = 0,
	[14] = 0,
	[15] = 0,
	[16] = 0,
	[17] = 0,
	[18] = 0,
	[19] = 0,
	[20] = 0,
	[21] = 0,
	[22] = 0,
	[23] = 0,
	[24] = 0,
	[25] = 0,
	[26] = 0,
	[27] = 0,
	[28] = 0,
	[29] = 0,
	[30] = 0,
	[31] = 0,
	[32] = 0,
	[33] = 0,
	[34] = 0,
	[35] = 0,
	[36] = 0,
	[37] = 0,
	[38] = 0,
	[39] = 0,
	[40] = 0,
	[41] = 0,
	[42] = 0,
	[43] = 0,
	[101] = 0,
	[102] = 0,
	[103] = 0,
	[104] = 0,
	[105] = 0,
}
-- -------------------back_limit_end---------------------
