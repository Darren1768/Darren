----------------------------------------------------
-- 此文件由数据工具生成
-- 配置数据--sound_data.xml
--------------------------------------

Config = Config or {} 
Config.SoundData = Config.SoundData or {}

-- -------------------get_sound_data_start-------------------
Config.SoundData.data_get_sound_data_length = 8
Config.SoundData.data_get_sound_data = {
	["R01000"] = {sound_id="R01000", act_sound="b_han3", hit_sound="b_hurt2"},
	["R11000"] = {sound_id="R11000", act_sound="b_han2", hit_sound="b_hurt"},
	["R10500"] = {sound_id="R10500", act_sound="b_han8", hit_sound="b_hurt"},
	["R02100"] = {sound_id="R02100", act_sound="b_han1", hit_sound="b_hurt1"},
	["H30000"] = {sound_id="H30000", act_sound="b_han8", hit_sound="b_hurt"},
	["H30031"] = {sound_id="H30031", act_sound="b_han3", hit_sound="b_hurt2"},
	["H30032"] = {sound_id="H30032", act_sound="b_han3", hit_sound="b_hurt2"},
	["H30033"] = {sound_id="H30033", act_sound="b_han1", hit_sound="b_hurt1"}
}
Config.SoundData.data_get_sound_data_fun = function(key)
	local data=Config.SoundData.data_get_sound_data[key]
	if DATA_DEBUG and data == nil then
		print('(Config.SoundData.data_get_sound_data['..key..'])not found') return
	end
	return data
end
-- -------------------get_sound_data_end---------------------
