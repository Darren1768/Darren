--[[
        week_calendar_data.lua
        exported by excel2lua.py
        from file:week_calendar_data.xlsx
--]]


Config = Config or {}
Config.WeekCalendarData = Config.WeekCalendarData or {}

---------------------data_week_calendar start--------------------
Config.WeekCalendarData.data_week_calendar_length = 7
Config.WeekCalendarData.data_week_calendar = {
 [1] = {
    [1]={id=110,desc="无尽兽潮",hour_minute=0,seq=11,week=1},
    [2]={id=109,desc="乾坤八方",hour_minute=0,seq=10,week=1},
    [3]={id=108,desc="六问轩辕",hour_minute=0,seq=9,week=1},
    [4]={id=107,desc="五行天地",hour_minute=0,seq=8,week=1},
    [5]={id=106,desc="龙宫探宝",hour_minute=0,seq=7,week=1},
    [6]={id=105,desc="远航商人",hour_minute=0,seq=6,week=1},
    [7]={id=104,desc="捉妖驱鬼",hour_minute=0,seq=5,week=1},
    [8]={id=103,desc="十三翼战场",hour_minute=0,seq=4,week=1},
    [9]={id=102,desc="贼王宝图",hour_minute=0,seq=3,week=1},
    [10]={id=101,desc="囚龙岛",hour_minute=0,seq=2,week=1},
    [11]={id=100,desc="学院任务",hour_minute=0,seq=1,week=1}},
 [2] = {
    [1]={id=121,desc="炎火城战",hour_minute=0,seq=11,week=2},
    [2]={id=120,desc="黑水城战",hour_minute=0,seq=10,week=2},
    [3]={id=119,desc="九天之上",hour_minute=0,seq=9,week=2},
    [4]={id=118,desc="七杀阵",hour_minute=0,seq=8,week=2},
    [5]={id=117,desc="四门绝阵",hour_minute=0,seq=7,week=2},
    [6]={id=116,desc="精英竞技",hour_minute=0,seq=6,week=2},
    [7]={id=115,desc="神界试炼",hour_minute=0,seq=5,week=2},
    [8]={id=114,desc="科举殿试",hour_minute=0,seq=4,week=2},
    [9]={id=113,desc="美食达人",hour_minute=0,seq=3,week=2},
    [10]={id=112,desc="极限斗争",hour_minute=0,seq=2,week=2},
    [11]={id=111,desc="魂师大赛",hour_minute=0,seq=1,week=2}},
 [3] = {
    [1]={id=110,desc="无尽兽潮",hour_minute=0,seq=11,week=3},
    [2]={id=109,desc="乾坤八方",hour_minute=0,seq=10,week=3},
    [3]={id=108,desc="六问轩辕",hour_minute=0,seq=9,week=3},
    [4]={id=107,desc="五行天地",hour_minute=0,seq=8,week=3},
    [5]={id=106,desc="龙宫探宝",hour_minute=0,seq=7,week=3},
    [6]={id=105,desc="远航商人",hour_minute=0,seq=6,week=3},
    [7]={id=104,desc="捉妖驱鬼",hour_minute=0,seq=5,week=3},
    [8]={id=103,desc="十三翼战场",hour_minute=0,seq=4,week=3},
    [9]={id=102,desc="贼王宝图",hour_minute=0,seq=3,week=3},
    [10]={id=101,desc="囚龙岛",hour_minute=0,seq=2,week=3},
    [11]={id=100,desc="学院任务",hour_minute=0,seq=1,week=3}},
 [4] = {
    [1]={id=121,desc="炎火城战",hour_minute=0,seq=11,week=4},
    [2]={id=120,desc="黑水城战",hour_minute=0,seq=10,week=4},
    [3]={id=119,desc="九天之上",hour_minute=0,seq=9,week=4},
    [4]={id=118,desc="七杀阵",hour_minute=0,seq=8,week=4},
    [5]={id=117,desc="四门绝阵",hour_minute=0,seq=7,week=4},
    [6]={id=116,desc="精英竞技",hour_minute=0,seq=6,week=4},
    [7]={id=115,desc="神界试炼",hour_minute=0,seq=5,week=4},
    [8]={id=114,desc="科举殿试",hour_minute=0,seq=4,week=4},
    [9]={id=113,desc="美食达人",hour_minute=0,seq=3,week=4},
    [10]={id=112,desc="极限斗争",hour_minute=0,seq=2,week=4},
    [11]={id=111,desc="魂师大赛",hour_minute=0,seq=1,week=4}},
 [5] = {
    [1]={id=110,desc="无尽兽潮",hour_minute=0,seq=11,week=5},
    [2]={id=109,desc="乾坤八方",hour_minute=0,seq=10,week=5},
    [3]={id=108,desc="六问轩辕",hour_minute=0,seq=9,week=5},
    [4]={id=107,desc="五行天地",hour_minute=0,seq=8,week=5},
    [5]={id=106,desc="龙宫探宝",hour_minute=0,seq=7,week=5},
    [6]={id=105,desc="远航商人",hour_minute=0,seq=6,week=5},
    [7]={id=104,desc="捉妖驱鬼",hour_minute=0,seq=5,week=5},
    [8]={id=103,desc="十三翼战场",hour_minute=0,seq=4,week=5},
    [9]={id=102,desc="贼王宝图",hour_minute=0,seq=3,week=5},
    [10]={id=101,desc="囚龙岛",hour_minute=0,seq=2,week=5},
    [11]={id=100,desc="学院任务",hour_minute=0,seq=1,week=5}},
 [6] = {
    [1]={id=121,desc="炎火城战",hour_minute=0,seq=11,week=6},
    [2]={id=120,desc="黑水城战",hour_minute=0,seq=10,week=6},
    [3]={id=119,desc="九天之上",hour_minute=0,seq=9,week=6},
    [4]={id=118,desc="七杀阵",hour_minute=0,seq=8,week=6},
    [5]={id=117,desc="四门绝阵",hour_minute=0,seq=7,week=6},
    [6]={id=116,desc="精英竞技",hour_minute=0,seq=6,week=6},
    [7]={id=115,desc="神界试炼",hour_minute=0,seq=5,week=6},
    [8]={id=114,desc="科举殿试",hour_minute=0,seq=4,week=6},
    [9]={id=113,desc="美食达人",hour_minute=0,seq=3,week=6},
    [10]={id=112,desc="极限斗争",hour_minute=0,seq=2,week=6},
    [11]={id=111,desc="魂师大赛",hour_minute=0,seq=1,week=6}},
 [7] = {
    [1]={id=114,desc="科举殿试",hour_minute=0,seq=11,week=7},
    [2]={id=113,desc="美食达人",hour_minute=0,seq=10,week=7},
    [3]={id=121,desc="炎火城战",hour_minute=0,seq=9,week=7},
    [4]={id=120,desc="黑水城战",hour_minute=0,seq=8,week=7},
    [5]={id=119,desc="九天之上",hour_minute=0,seq=7,week=7},
    [6]={id=118,desc="七杀阵",hour_minute=0,seq=6,week=7},
    [7]={id=117,desc="四门绝阵",hour_minute=0,seq=5,week=7},
    [8]={id=116,desc="精英竞技",hour_minute=0,seq=4,week=7},
    [9]={id=115,desc="神界试炼",hour_minute=0,seq=3,week=7},
    [10]={id=114,desc="科举殿试",hour_minute=0,seq=2,week=7},
    [11]={id=113,desc="美食达人",hour_minute=0,seq=1,week=7}}
}
Config.WeekCalendarData.data_week_calendar_fun = function(key)
    local data =Config.WeekCalendarData.data_week_calendar[key]
    if DATA_DEBUG and data == nil then
        print('( Config.WeekCalendarData.data_week_calendar['..key..'])not found') return
    end
    return data
end
---------------------data_week_calendar end--------------------
---------------------data_all_time start--------------------
Config.WeekCalendarData.data_all_time_length = 11
Config.WeekCalendarData.data_all_time = {
 [1] = {hour_minute=0,seq=1},
 [2] = {hour_minute=0,seq=2},
 [3] = {hour_minute=0,seq=3},
 [4] = {hour_minute=0,seq=4},
 [5] = {hour_minute=0,seq=5},
 [6] = {hour_minute=0,seq=6},
 [7] = {hour_minute=0,seq=7},
 [8] = {hour_minute=0,seq=8},
 [9] = {hour_minute=0,seq=9},
 [10] = {hour_minute=0,seq=10},
 [11] = {hour_minute=0,seq=11}
}
Config.WeekCalendarData.data_all_time_fun = function(key)
    local data =Config.WeekCalendarData.data_all_time[key]
    if DATA_DEBUG and data == nil then
        print('( Config.WeekCalendarData.data_all_time['..key..'])not found') return
    end
    return data
end
---------------------data_all_time end--------------------
