----------------------------------------------------
-- 此文件由数据工具生成
-- 公告配置数据--notice_data.xml
--------------------------------------

Config = Config or {} 
Config.NoticeData = Config.NoticeData or {}

-- -------------------get_start-------------------
Config.NoticeData.data_get_length = 27
Config.NoticeData.data_get = {
	[1] = {id=1, name="邮件提示", label="mail", can_overly=1, res="1007"},
	[2] = {id=2, name="加好友提示", label="add_friend", can_overly=1, res="1004"},
	[4] = {id=4, name="加宗门提示", label="join_guild", can_overly=1, res="1001"},
	[6] = {id=6, name="切磋请求", label="challenge", can_overly=1, res="1006"},
	[8] = {id=8, name="私聊提示", label="private_chat", can_overly=1, res="1005"},
	[9] = {id=9, name="邀请帮会提示", label="invite_join_guild", can_overly=1, res="1002"},
	[10] = {id=10, name="集结号角", label="guild_mass", can_overly=1, res="1003"},
	[11] = {id=11, name="合并提示", label="guild_merge", can_overly=1, res="1002"},
	[12] = {id=12, name="试炼邀请", label="team", can_overly=1, res="1006"},
	[13] = {id=13, name="赠送体力", label="give", can_overly=1, res="1008"},
	[14] = {id=14, name="世界Boss刷新", label="world_boss", can_overly=1, res="1008"},
	[15] = {id=15, name="有人@你", label="mention", can_overly=1, res="1008"},
	[16] = {id=16, name="无尽试炼选buff", label="endless", can_overly=1, res="1008"},
	[17] = {id=17, name="萌兽夺宝完成", label="escort", can_overly=1, res="1008"},
	[18] = {id=18, name="帮会Boss集结", label="guild_dun", can_overly=1, res="1008"},
	[19] = {id=19, name="公会捐献提醒", label="guild", can_overly=1, res="1008"},
	[20] = {id=20, name="公会战提醒", label="guild_war", can_overly=1, res="1008"},
	[21] = {id=21, name="公会副本提醒", label="guild_voyage", can_overly=1, res="1008"},
	[22] = {id=22, name="留言板有新消息", label="bbs_message", can_overly=0, res="1008"},
	[23] = {id=23, name="他人留言板有新消息", label="bbs_message_reply", can_overly=0, res="1008"},
	[24] = {id=24, name="留言板有新回复", label="bbs_message_reply_self", can_overly=0, res="1008"},
	[25] = {id=25, name="灵矿防守失败", label="mine_defeat", can_overly=1, res="1008"},
	[26] = {id=26, name="巅峰冠军赛竞猜", label="Peak_champion_arena_tips", can_overly=1, res="1008"},
	[27] = {id=27, name="跨服竞技场挑战", label="Corss_arena_tips", can_overly=1, res="1008"},
	[28] = {id=28, name="限时年兽挑战", label="Year_Monster_tips", can_overly=1, res="1008"},
	[29] = {id=29, name="符文合成提醒", label="Artifact_Count_tips", can_overly=1, res="1008"},
	[30] = {id=30, name="协力赛挑战提醒", label="team_battle_tips", can_overly=1, res="1008"}
}
Config.NoticeData.data_get_fun = function(key)
	local data=Config.NoticeData.data_get[key]
	if DATA_DEBUG and data == nil then
		print('(Config.NoticeData.data_get['..key..'])not found') return
	end
	return data
end
-- -------------------get_end---------------------
