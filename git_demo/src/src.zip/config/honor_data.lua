----------------------------------------------------
-- 此文件由数据工具生成
-- 称号数据--honor_data.xml
--------------------------------------

Config = Config or {} 
Config.HonorData = Config.HonorData or {}

-- -------------------title_start-------------------
Config.HonorData.data_title_length = 72
Config.HonorData.data_title = {
	[90003] = {base_id=90003, name="最强王者", group=1001, loss={{50012,1}}, desc="冠军赛排名第一", expire_time=5760, is_panel=1, is_show=1, res_id=13, attr={{'hp_max',1200},{'atk',250}}, add_exp=0, source=42, is_show_title=0},
	[90004] = {base_id=90004, name="星辰勇者", group=1002, loss={{50013,1}}, desc="冠军赛排名第二", expire_time=5760, is_panel=1, is_show=1, res_id=14, attr={{'hp_max',800},{'atk',150}}, add_exp=0, source=42, is_show_title=0},
	[90005] = {base_id=90005, name="苍蓝斗士", group=1003, loss={{50014,1}}, desc="冠军赛排名第三", expire_time=5760, is_panel=1, is_show=1, res_id=15, attr={{'hp_max',500},{'atk',100}}, add_exp=0, source=42, is_show_title=0},
	[90006] = {base_id=90006, name="大探险家", group=1004, loss={{50101,1}}, desc="七天排行剧情进度第一", expire_time=0, is_panel=1, is_show=0, res_id=6, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[90007] = {base_id=90007, name="爬塔达人", group=1005, loss={{50102,1}}, desc="七天排行星命塔第一", expire_time=0, is_panel=1, is_show=0, res_id=7, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=44, is_show_title=0},
	[90008] = {base_id=90008, name="竞技天王", group=1006, loss={{50103,1}}, desc="七天排行竞技场第一", expire_time=0, is_panel=1, is_show=0, res_id=8, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=42, is_show_title=0},
	[90009] = {base_id=90009, name="地表最强", group=1007, loss={{50104,1}}, desc="七天排行战力排名第一", expire_time=0, is_panel=1, is_show=0, res_id=9, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[90010] = {base_id=90010, name="星耀之灵", group=1008, loss={{50105,1}}, desc="七天排行星命评分第一", expire_time=0, is_panel=1, is_show=0, res_id=10, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=45, is_show_title=0},
	[90011] = {base_id=90011, name="最强英雄", group=1009, loss={{50106,1}}, desc="七天排行英雄战力第一", expire_time=0, is_panel=1, is_show=0, res_id=11, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[90012] = {base_id=90012, name="翱游神界", group=1010, loss={{50107,1}}, desc="七天排行神界冒险第一", expire_time=0, is_panel=1, is_show=0, res_id=12, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=46, is_show_title=0},
	[90013] = {base_id=90013, name="寻宝专家", group=1033, loss={{50108,1}}, desc="七天排行寻宝第一", expire_time=0, is_panel=1, is_show=0, res_id=100, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[90100] = {base_id=90100, name="爬塔新手", group=1011, loss={{50200,1}}, desc="星命塔通关10层后获得", expire_time=0, is_panel=0, is_show=0, res_id=16, attr={{'hp_max',100},{'atk',20}}, add_exp=0, source=44, is_show_title=0},
	[90101] = {base_id=90101, name="节节攀升", group=1012, loss={{50200,1}}, desc="星命塔通关30层后获得", expire_time=0, is_panel=0, is_show=0, res_id=17, attr={{'hp_max',100},{'atk',20},{'def',15}}, add_exp=0, source=44, is_show_title=0},
	[90102] = {base_id=90102, name="爬塔能手", group=1013, loss={{50200,1}}, desc="星命塔通关50层后获得", expire_time=0, is_panel=0, is_show=0, res_id=18, attr={{'hp_max',100},{'atk',20},{'def',15}}, add_exp=0, source=44, is_show_title=0},
	[90103] = {base_id=90103, name="一览无穷", group=1014, loss={{50200,1}}, desc="星命塔通关70层后获得", expire_time=0, is_panel=0, is_show=0, res_id=19, attr={{'hp_max',200},{'atk',40},{'def',30}}, add_exp=0, source=44, is_show_title=0},
	[90104] = {base_id=90104, name="突破天际", group=1015, loss={{50200,1}}, desc="星命塔通关90层后获得", expire_time=0, is_panel=0, is_show=0, res_id=20, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=44, is_show_title=0},
	[90105] = {base_id=90105, name="越战越勇", group=1016, loss={{50200,1}}, desc="星命塔通关110层后获得", expire_time=0, is_panel=0, is_show=0, res_id=21, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=44, is_show_title=0},
	[90106] = {base_id=90106, name="冠军之心", group=1017, loss={{50301,1}}, desc="竞猜商店兑换获得", expire_time=0, is_panel=1, is_show=0, res_id=22, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=81, is_show_title=0},
	[90401] = {base_id=90401, name="破军之巅", group=1018, loss={{50401,1}}, desc="无尽试炼排行榜排名第一", expire_time=1440, is_panel=1, is_show=0, res_id=23, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=90, is_show_title=0},
	[90402] = {base_id=90402, name="不屈意志", group=1019, loss={{50402,1}}, desc="无尽试炼排行榜排名第二", expire_time=1440, is_panel=1, is_show=0, res_id=24, attr={{'hp_max',200},{'atk',40},{'def',30}}, add_exp=0, source=90, is_show_title=0},
	[90403] = {base_id=90403, name="初露锋芒", group=1020, loss={{50403,1}}, desc="无尽试炼排行榜排名第三", expire_time=1440, is_panel=1, is_show=0, res_id=25, attr={{'hp_max',100},{'atk',20},{'def',15}}, add_exp=0, source=90, is_show_title=0},
	[90501] = {base_id=90501, name="冰天雪地", group=1021, loss={{50501,1}}, desc="神将限时兑换活动获得", expire_time=0, is_panel=1, is_show=0, res_id=26, attr={{'hp_max',200},{'atk',40},{'def',30}}, add_exp=0, source=0, is_show_title=0},
	[90502] = {base_id=90502, name="黑暗世界", group=1022, loss={{50502,1}}, desc="神将限时兑换活动获得", expire_time=0, is_panel=1, is_show=0, res_id=27, attr={{'hp_max',200},{'atk',40},{'def',30}}, add_exp=0, source=0, is_show_title=0},
	[90601] = {base_id=90601, name="战场勇者", group=1023, loss={{50601,1}}, desc="众神战场第三名", expire_time=1440, is_panel=1, is_show=0, res_id=28, attr={{'hp_max',100},{'atk',20},{'def',15}}, add_exp=0, source=0, is_show_title=0},
	[90602] = {base_id=90602, name="战场霸主", group=1024, loss={{50602,1}}, desc="众神战场第二名", expire_time=1440, is_panel=1, is_show=0, res_id=29, attr={{'hp_max',200},{'atk',40},{'def',30}}, add_exp=0, source=0, is_show_title=0},
	[90603] = {base_id=90603, name="不败神话", group=1025, loss={{50603,1}}, desc="众神战场第一名", expire_time=1440, is_panel=1, is_show=0, res_id=30, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[90701] = {base_id=90701, name="耀眼光芒", group=1026, loss={{50111,1}}, desc="跨服七天排行宝石等级第一", expire_time=0, is_panel=1, is_show=0, res_id=31, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[90702] = {base_id=90702, name="圣器王者", group=1027, loss={{50112,1}}, desc="跨服七天排行圣器战力第一", expire_time=0, is_panel=1, is_show=0, res_id=32, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=100, is_show_title=0},
	[90703] = {base_id=90703, name="观星大师", group=1028, loss={{50113,1}}, desc="跨服七天排行观星次数第一", expire_time=0, is_panel=1, is_show=0, res_id=33, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=45, is_show_title=0},
	[90704] = {base_id=90704, name="试炼之王", group=1029, loss={{50114,1}}, desc="跨服七天排行无尽试炼第一", expire_time=0, is_panel=1, is_show=0, res_id=34, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=90, is_show_title=0},
	[90705] = {base_id=90705, name="英雄无敌", group=1030, loss={{50115,1}}, desc="跨服七天排行召唤次数第一", expire_time=0, is_panel=1, is_show=0, res_id=35, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=1, is_show_title=0},
	[90706] = {base_id=90706, name="战力至上", group=1031, loss={{50116,1}}, desc="跨服七天排行英雄战力第一", expire_time=0, is_panel=1, is_show=0, res_id=36, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[90707] = {base_id=90707, name="最强土豪", group=1032, loss={{50117,1}}, desc="跨服七天排行蓝钻消耗第一", expire_time=0, is_panel=1, is_show=0, res_id=37, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[90801] = {base_id=90801, name="万殿之巅", group=1050, loss={{50701,1}}, desc="在星河神殿占有“万殿之巅”神位", expire_time=0, is_panel=1, is_show=1, res_id=38, attr={{'hp_max_per',30},{'atk_per',30}}, add_exp=0, source=102, is_show_title=0},
	[90802] = {base_id=90802, name="泰坦神耀", group=1051, loss={{50702,1}}, desc="在星河神殿占有“泰坦之耀”神位", expire_time=0, is_panel=1, is_show=1, res_id=39, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=102, is_show_title=0},
	[90803] = {base_id=90803, name="瀚海星灵", group=1052, loss={{50703,1}}, desc="在星河神殿占有“瀚海星灵”神位", expire_time=0, is_panel=1, is_show=1, res_id=40, attr={{'hp_max_per',10},{'atk_per',10}}, add_exp=0, source=102, is_show_title=0},
	[90901] = {base_id=90901, name="寻宝幸运星", group=1053, loss={{50302,1}}, desc="幸运探宝活动中获得", expire_time=0, is_panel=1, is_show=0, res_id=41, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[90902] = {base_id=90902, name="最强幸运星", group=1054, loss={{50303,1}}, desc="幸运探宝活动中获得", expire_time=0, is_panel=1, is_show=0, res_id=42, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[90903] = {base_id=90903, name="神之眷顾", group=1055, loss={{50304,1}}, desc="幸运探宝活动中获得", expire_time=0, is_panel=1, is_show=0, res_id=43, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=0, source=0, is_show_title=0},
	[91001] = {base_id=91001, name="登峰造极", group=1056, loss={{50801,1}}, desc="跨服天梯-第一名获得", expire_time=10080, is_panel=1, is_show=1, res_id=44, attr={{'hp_max',1200},{'atk',250}}, add_exp=0, source=0, is_show_title=0},
	[91002] = {base_id=91002, name="名列前茅", group=1057, loss={{50802,1}}, desc="跨服天梯-第二名获得", expire_time=10080, is_panel=1, is_show=1, res_id=45, attr={{'hp_max',800},{'atk',150}}, add_exp=0, source=0, is_show_title=0},
	[91003] = {base_id=91003, name="天梯达人", group=1058, loss={{50803,1}}, desc="跨服天梯-第三名获得", expire_time=10080, is_panel=1, is_show=1, res_id=46, attr={{'hp_max',500},{'atk',100}}, add_exp=0, source=0, is_show_title=0},
	[92001] = {base_id=92001, name="闪烁之光", group=1060, loss={{50305,1}}, desc="新服活动中获得", expire_time=0, is_panel=1, is_show=0, res_id=101, attr={{'hp_max',300},{'atk',60},{'def',45}}, add_exp=100, source=0, is_show_title=0},
	[99003] = {base_id=99003, name="花灯福愿", group=1061, loss={{50901,1}}, desc="2019年元宵活动纪念称号", expire_time=0, is_panel=1, is_show=1, res_id=48, attr={{'hp_max',10},{'atk',10}}, add_exp=0, source=0, is_show_title=0},
	[99004] = {base_id=99004, name="心动闪烁", group=1062, loss={{50902,1}}, desc="为答谢参与闪烁北京线下活动的有爱之人，特别的定制称号", expire_time=0, is_panel=1, is_show=1, res_id=52, attr={{'hp_max',10},{'atk',10}}, add_exp=0, source=0, is_show_title=1},
	[99005] = {base_id=99005, name="缤纷夏日", group=1063, loss={{50903,1}}, desc="赠与在沙滩保卫战活动中，挑战自我的最强冒险者们", expire_time=0, is_panel=1, is_show=1, res_id=53, attr={{'hp_max',10},{'atk',10}}, add_exp=0, source=0, is_show_title=0},
	[99006] = {base_id=99006, name="英灵勇士", group=1064, loss={{50904,1}}, desc="在“英灵战令”活动中获得，是冒险大陆上无畏勇士的象征", expire_time=43200, is_panel=1, is_show=1, res_id=54, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99007] = {base_id=99007, name="荣耀之光", group=1065, loss={{50905,1}}, desc="荣耀！只会赠与冒险大陆上最勇敢的战士", expire_time=0, is_panel=1, is_show=1, res_id=55, attr={{'hp_max',10},{'atk',10}}, add_exp=0, source=0, is_show_title=1},
	[99008] = {base_id=99008, name="冒险骑士团", group=1066, loss={{50906,1}}, desc="小助手颁发的纪念勋章，大人的付出被广大冒险者们所认可。", expire_time=0, is_panel=1, is_show=1, res_id=59, attr={{'hp_max',10},{'atk',10}}, add_exp=0, source=0, is_show_title=1},
	[99009] = {base_id=99009, name="冒险勇士", group=1067, loss={{50907,1}}, desc="在“冒险战纪”活动中获得，是成功完成冒险终极试炼的象征", expire_time=43200, is_panel=1, is_show=1, res_id=60, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99010] = {base_id=99010, name="勇者归来", group=1068, loss={{50908,1}}, desc="在“荣耀回归”活动中获得，是冒险大陆上回归玩家的象征", expire_time=0, is_panel=1, is_show=1, res_id=61, attr={{'hp_max',10},{'atk',10}}, add_exp=0, source=0, is_show_title=1},
	[99011] = {base_id=99011, name="潮汐猎人", group=1069, loss={{50909,1}}, desc="在“缤纷盛夏”活动中获得，是成功完成盛夏考验的象征", expire_time=43200, is_panel=1, is_show=1, res_id=62, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99012] = {base_id=99012, name="神奏之音", group=1070, loss={{50910,1}}, desc="在“轻音乐章”活动中获得，是音乐的力量鼓舞勇士前进的象征", expire_time=43200, is_panel=1, is_show=1, res_id=63, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99013] = {base_id=99013, name="一等学霸", group=1171, loss={{50911,1}}, desc="在“开学迎新”活动中获得，是魔法学院超级学霸的象征", expire_time=43200, is_panel=1, is_show=1, res_id=64, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99014] = {base_id=99014, name="花火映秋", group=1172, loss={{50912,1}}, desc="在“花火映秋”活动中获得，是成功完成秋日考验的象征", expire_time=43200, is_panel=1, is_show=1, res_id=65, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99015] = {base_id=99015, name="神壕登场", group=1173, loss={{50913,1}}, desc="在节日活动中获得，是神壕的象征", expire_time=43200, is_panel=1, is_show=1, res_id=66, attr={{'hp_max',10},{'atk',10}}, add_exp=0, source=0, is_show_title=1},
	[99016] = {base_id=99016, name="奇妙之夜", group=1174, loss={{50914,1}}, desc="在“奇妙之夜”活动中获得，是奇妙之夜派对的礼物", expire_time=43200, is_panel=1, is_show=1, res_id=70, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99017] = {base_id=99017, name="雪舞冬季", group=1175, loss={{50915,1}}, desc="在“雪舞冬季”活动中获得，是冬日的礼物", expire_time=43200, is_panel=1, is_show=1, res_id=71, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99018] = {base_id=99018, name="王者之辉", group=1176, loss={{50916,1}}, desc="在段位赛“王者之证”活动中获得", expire_time=43200, is_panel=1, is_show=1, res_id=72, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99019] = {base_id=99019, name="重逢之旅", group=1177, loss={{50917,1}}, desc="在“重逢之旅”活动中获得", expire_time=43200, is_panel=1, is_show=1, res_id=102, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99020] = {base_id=99020, name="2020", group=1178, loss={{50918,1}}, desc="在“岁初礼赞”活动中获得，是新年的礼物", expire_time=43200, is_panel=1, is_show=1, res_id=73, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[99021] = {base_id=99021, name="最强土豪", group=1179, loss={{50919,1}}, desc="在节日活动中获得，是最强土豪的象征", expire_time=43200, is_panel=1, is_show=1, res_id=74, attr={{'hp_max',10},{'atk',10}}, add_exp=0, source=0, is_show_title=1},
	[99022] = {base_id=99022, name="踏雪花晨", group=1180, loss={{50920,1}}, desc="在“踏雪拾春”活动中获得，是春天希望的象征", expire_time=43200, is_panel=1, is_show=1, res_id=75, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=0, is_show_title=0},
	[91101] = {base_id=91101, name="超凡之巅", group=1071, loss={{51001,1}}, desc="超凡段位赛-第1名(到达王者段位)获得", expire_time=0, is_panel=1, is_show=1, res_id=49, attr={{'hp_max_per',30},{'atk_per',30}}, add_exp=0, source=115, is_show_title=0},
	[91102] = {base_id=91102, name="灵耀王者", group=1072, loss={{51002,1}}, desc="超凡段位赛-第2-3名(到达王者段位)获得", expire_time=0, is_panel=1, is_show=1, res_id=50, attr={{'hp_max_per',20},{'atk_per',20}}, add_exp=0, source=115, is_show_title=0},
	[91103] = {base_id=91103, name="洛辉宗师", group=1073, loss={{51003,1}}, desc="超凡段位赛-第4-6名(到达王者段位)获得", expire_time=0, is_panel=1, is_show=1, res_id=51, attr={{'hp_max_per',10},{'atk_per',10}}, add_exp=0, source=115, is_show_title=0},
	[91201] = {base_id=91201, name="天启战神", group=1081, loss={{51101,1}}, desc="跨服竞技场-第一名获得", expire_time=10080, is_panel=1, is_show=1, res_id=56, attr={{'hp_max',1200},{'atk',250}}, add_exp=0, source=0, is_show_title=0},
	[91202] = {base_id=91202, name="月耀领主", group=1082, loss={{51102,1}}, desc="跨服竞技场-第二名获得", expire_time=10080, is_panel=1, is_show=1, res_id=58, attr={{'hp_max',800},{'atk',150}}, add_exp=0, source=0, is_show_title=0},
	[91203] = {base_id=91203, name="星灵勇者", group=1083, loss={{51103,1}}, desc="跨服竞技场-第三名获得", expire_time=10080, is_panel=1, is_show=1, res_id=57, attr={{'hp_max',500},{'atk',100}}, add_exp=0, source=0, is_show_title=0},
	[91301] = {base_id=91301, name="闪耀群星", group=1091, loss={{51201,1}}, desc="组队竞技场第一名获得", expire_time=10080, is_panel=1, is_show=1, res_id=67, attr={{'hp_max',1200},{'atk',250}}, add_exp=0, source=0, is_show_title=0},
	[91302] = {base_id=91302, name="荣耀军团", group=1092, loss={{51202,1}}, desc="组队竞技场第二、三名获得", expire_time=10080, is_panel=1, is_show=1, res_id=68, attr={{'hp_max',800},{'atk',150}}, add_exp=0, source=0, is_show_title=0},
	[91303] = {base_id=91303, name="强强联合", group=1093, loss={{51203,1}}, desc="组队竞技场第四、五名获得", expire_time=10080, is_panel=1, is_show=1, res_id=69, attr={{'hp_max',500},{'atk',100}}, add_exp=0, source=0, is_show_title=0}
}
Config.HonorData.data_title_fun = function(key)
	local data=Config.HonorData.data_title[key]
	if DATA_DEBUG and data == nil then
		print('(Config.HonorData.data_title['..key..'])not found') return
	end
	return data
end
-- -------------------title_end---------------------
