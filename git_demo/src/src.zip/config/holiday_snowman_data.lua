--[[
        holiday_snowman_data.lua
        exported by excel2lua.py
        from file:holiday_snowman_data.xlsx
--]]


Config = Config or {}
Config.HolidaySnowmanData = Config.HolidaySnowmanData or {}

---------------------data_happy_list start--------------------
Config.HolidaySnowmanData.data_happy_list_length = 4
Config.HolidaySnowmanData.data_happy_list = {
 [100] = {happy_val=100,rewards={{14801,1}}},
 [250] = {happy_val=250,rewards={{14801,1}}},
 [400] = {happy_val=400,rewards={{14801,1}}},
 [600] = {happy_val=600,rewards={{14802,1}}}
}
Config.HolidaySnowmanData.data_happy_list_fun = function(key)
    local data =Config.HolidaySnowmanData.data_happy_list[key]
    if DATA_DEBUG and data == nil then
        print('( Config.HolidaySnowmanData.data_happy_list['..key..'])not found') return
    end
    return data
end
---------------------data_happy_list end--------------------
---------------------data_const_data start--------------------
Config.HolidaySnowmanData.data_const_data_length = 1
Config.HolidaySnowmanData.data_const_data = {
 ["cost_item"] = {desc="消耗道具",key="cost_item",val=14803}
}
Config.HolidaySnowmanData.data_const_data_fun = function(key)
    local data =Config.HolidaySnowmanData.data_const_data[key]
    if DATA_DEBUG and data == nil then
        print('( Config.HolidaySnowmanData.data_const_data['..key..'])not found') return
    end
    return data
end
---------------------data_const_data end--------------------
---------------------data_item_data start--------------------
Config.HolidaySnowmanData.data_item_data_length = 1
Config.HolidaySnowmanData.data_item_data = {
 [14803] = {base_id=14803,happy_val=1,reward_id=14800}
}
Config.HolidaySnowmanData.data_item_data_fun = function(key)
    local data =Config.HolidaySnowmanData.data_item_data[key]
    if DATA_DEBUG and data == nil then
        print('( Config.HolidaySnowmanData.data_item_data['..key..'])not found') return
    end
    return data
end
---------------------data_item_data end--------------------
