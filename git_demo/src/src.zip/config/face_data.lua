----------------------------------------------------
-- 此文件由数据工具生成
-- 配置数据--face_data.xml
--------------------------------------

Config = Config or {} 
Config.FaceData = Config.FaceData or {}

-- -------------------biaoqing_start-------------------
Config.FaceData.data_biaoqing_length = 57
Config.FaceData.data_biaoqing = {
	[1] = {id=1, name="E61526", width=45, height=45},
	[2] = {id=2, name="E61527", width=45, height=45},
	[3] = {id=3, name="E61528", width=45, height=45},
	[4] = {id=4, name="E61529", width=45, height=45},
	[5] = {id=5, name="E61530", width=45, height=45},
	[6] = {id=6, name="E61531", width=45, height=45},
	[7] = {id=7, name="E61532", width=45, height=45},
	[8] = {id=8, name="E61533", width=45, height=45},
	[9] = {id=9, name="E61534", width=45, height=45},
	[10] = {id=10, name="E61535", width=45, height=45},
	[11] = {id=11, name="E61536", width=45, height=45},
	[12] = {id=12, name="E61537", width=45, height=45},
	[13] = {id=13, name="E61538", width=45, height=45},
	[14] = {id=14, name="E61539", width=45, height=45},
	[15] = {id=15, name="E61540", width=45, height=45},
	[16] = {id=16, name="E61541", width=45, height=45},
	[17] = {id=17, name="E61542", width=45, height=45},
	[18] = {id=18, name="E61543", width=45, height=45},
	[19] = {id=19, name="E61544", width=45, height=45},
	[20] = {id=20, name="E61545", width=45, height=45},
	[21] = {id=21, name="E61546", width=45, height=45},
	[22] = {id=22, name="E61547", width=45, height=45},
	[23] = {id=23, name="E61548", width=45, height=45},
	[24] = {id=24, name="E61549", width=45, height=45},
	[25] = {id=25, name="E61550", width=45, height=45},
	[26] = {id=26, name="E61551", width=45, height=45},
	[27] = {id=27, name="E61552", width=45, height=45},
	[28] = {id=28, name="E61553", width=45, height=45},
	[29] = {id=29, name="E61554", width=45, height=45},
	[30] = {id=30, name="E61555", width=45, height=45},
	[31] = {id=31, name="E61556", width=45, height=45},
	[32] = {id=32, name="E61557", width=45, height=45},
	[33] = {id=33, name="E61558", width=45, height=45},
	[34] = {id=34, name="E61559", width=45, height=45},
	[35] = {id=35, name="E61560", width=45, height=45},
	[36] = {id=36, name="E61561", width=45, height=45},
	[37] = {id=37, name="E61562", width=45, height=45},
	[38] = {id=38, name="E61563", width=45, height=45},
	[39] = {id=39, name="E61564", width=45, height=45},
	[40] = {id=40, name="E61565", width=45, height=45},
	[41] = {id=41, name="E61566", width=45, height=45},
	[42] = {id=42, name="E61567", width=45, height=45},
	[43] = {id=43, name="E61568", width=45, height=45},
	[44] = {id=44, name="E61569", width=45, height=45},
	[45] = {id=45, name="E61570", width=45, height=45},
	[46] = {id=46, name="E61571", width=45, height=45},
	[47] = {id=47, name="E61572", width=45, height=45},
	[48] = {id=48, name="E61573", width=45, height=45},
	[49] = {id=49, name="E61574", width=45, height=45},
	[50] = {id=50, name="E61575", width=45, height=45},
	[51] = {id=51, name="E61576", width=45, height=45},
	[52] = {id=52, name="E61577", width=45, height=45},
	[53] = {id=53, name="E61578", width=45, height=45},
	[54] = {id=54, name="E61579", width=45, height=45},
	[55] = {id=55, name="E61580", width=45, height=45},
	[56] = {id=56, name="E61581", width=45, height=45},
	[57] = {id=57, name="E61582", width=45, height=45}
}
Config.FaceData.data_biaoqing_fun = function(key)
	local data=Config.FaceData.data_biaoqing[key]
	if DATA_DEBUG and data == nil then
		print('(Config.FaceData.data_biaoqing['..key..'])not found') return
	end
	return data
end
-- -------------------biaoqing_end---------------------
