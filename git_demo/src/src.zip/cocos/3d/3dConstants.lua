if nil == cc.Terrain then
    return
end

cc.Terrain.CrackFixedType =
{
    SKIRT = 0, 
    INCREASE_LOWER = 1,
}

cc.Animate3DQuality =
{
	QUALITY_NONE = 0,
	QUALITY_LOW  = 1,
	QUALITY_HIGH = 2,
}
