AdventureActivityConst = AdventureActivityConst or {}

AdventureActivityConst.Ground_Type = {
	adventure = 1, --冒险
    adventure_mine = 2, --秘矿冒险
    element = 3, --元素
    heaven = 4,  -- 天界副本
}

-- 红点类型
AdventureActivityConst.Red_Type = {
	adventure = 1, --冒险
	element = 2, --元素
	heaven = 3,  -- 天界副本
    adventure_mine = 4 -- 秘矿冒险
}
