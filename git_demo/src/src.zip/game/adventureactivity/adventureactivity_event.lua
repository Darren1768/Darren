AdventureActivityEvent = AdventureActivityEvent or {}
