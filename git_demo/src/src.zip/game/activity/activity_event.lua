ActivityEvent = ActivityEvent or {}

ActivityEvent.EscortCount = "ActivityEvent.EscortCount"

