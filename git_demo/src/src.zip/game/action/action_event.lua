ActionEvent = ActionEvent or {}
--首充状态
ActionEvent.Update_First_Charge_Status = "ActionEvent.Update_First_Charge_Status"
--七天登录
ActionEvent.UPDATE_SEVEN_LOGIN_STATUS = "ActionEvent.UPDATE_SEVEN_LOGIN_STATUS"
ActionEvent.UPDATE_SEVEN_LOGIN_REWARDS = "ActionEvent.UPDATE_SEVEN_LOGIN_REWARDS"
--七天排行
ActionEvent.UPDATE_SEVEN_RANK_LIST = "ActionEvent.UPDATE_SEVEN_RANK_LIST"
ActionEvent.UPDATE_SEVEN_RANK_DATA = "ActionEvent.UPDATE_SEVEN_RANK_DATA"

ActionEvent.UPDATE_HOLIDAY_SIGNLE = "ActionEvent.UPDATE_HOLIDAY_SIGNLE"

ActionEvent.UPDATE_HOLIDAY_TAB_STATUS = "ActionEvent.UPDATE_HOLIDAY_TAB_STATUS"

ActionEvent.UPDATE_Delete_Btn = "ActionEvent.UPDATE_Delete_Btn"

ActionEvent.UPDATE_91005_Btn = "ActionEvent.UPDATE_91005_Btn"


ActionEvent.UPDATE_SEVENT_QUEST = "ActionEvent.UPDATE_SEVENT_QUEST"

ActionEvent.UPDATE_LOTTERY_REDPOINT = "ActionEvent.UPDATE_LOTTERY_REDPOINT"

--跨服排行
ActionEvent.UPDATE_CROSSSERVER_RANK_LIST = "ActionEvent.UPDATE_CROSSSERVER_RANK_LIST" --UPDATE_SEVEN_RANK_LIST
ActionEvent.UPDATE_CROSSSERVER_RANK_DATA = "ActionEvent.UPDATE_CROSSSERVER_RANK_DATA" --UPDATE_SEVEN_RANK_DATA
ActionEvent.UPDATE_CROSSSERVER_QUEST = "ActionEvent.UPDATE_CROSSSERVER_QUEST" -- UPDATE_SEVENT_QUEST

--七天目标
ActionEvent.UPDATE_SEVENT_GOAL = "ActionEvent.UPDATE_SEVENT_GOAL"

--七天领取
ActionEvent.UPDATE_SEVENT_GET = "ActionEvent.UPDATE_SEVENT_GET"

--直购礼包
ActionEvent.UPDATE_DIRECTGIFT_GET = "ActionEvent.UPDATE_DIRECTGIFT_GET"

--探宝
ActionEvent.UPDATE_LUCKYROUND_GET = "ActionEvent.UPDATE_LUCKYROUND_GET"
ActionEvent.UPDATE_LUCKLY_DATA = "ActionEvent.UPDATE_LUCKLY_DATA"
--探宝返回
ActionEvent.TREASURE_SUCCESS_DATA = "ActionEvent.TREASURE_SUCCESS_DATA"
--探宝记录
ActionEvent.UPDATA_TREASURE_LOG_DATA = "ActionEvent.UPDATA_TREASURE_LOG_DATA"
--弹窗请求的协议
ActionEvent.UPDATA_TREASURE_POPUPS_SEND = "ActionEvent.UPDATA_TREASURE_POPUPS_SEND"
--刷新
ActionEvent.UPDATA_TREASURE_REFRESH = "ActionEvent.UPDATA_TREASURE_REFRESH"
--升级有礼
ActionEvent.UPDATE_LEVEL_UP_GIFT = "ActionEvent.UPDATE_LEVEL_UP_GIFT"

--限时礼包入口
ActionEvent.LIMIT_GIFT_MAIN_EVENT = "ActionEvent.LIMIT_GIFT_MAIN_EVENT"

--排行奖励列表
ActionEvent.RANK_REWARD_LIST = "ActionEvent.RANK_REWARD_LIST"

-- 基金活动开启类型更新
ActionEvent.UPDATA_FUND_ID_LIST_EVENT = "ActionEvent.UPDATA_FUND_ID_LIST_EVENT"

-- 基金数据更新
ActionEvent.UPDATA_FUND_DATA_EVENT = "ActionEvent.UPDATA_FUND_DATA_EVENT"

-- 基金红点更新
ActionEvent.UPDATA_FUND_RED_STATUS_EVENT = "ActionEvent.UPDATA_FUND_RED_STATUS_EVENT"

--元宵冒险
ActionEvent.YUAN_ZHEN_DATA_EVENT = "ActionEvent.YUAN_ZHEN_DATA_EVENT"
--元宵冒险 推送更新
ActionEvent.YUAN_ZHEN_UPDATA_EVENT = "ActionEvent.YUAN_ZHEN_UPDATA_EVENT"
--元宵冒险 领任务
ActionEvent.YUAN_ZHEN_TASK_EVENT = "ActionEvent.YUAN_ZHEN_TASK_EVENT"

--是否可充值
ActionEvent.Is_Charge_Event = "ActionEvent.Is_Charge_Event"

--刷新红点(活动期间仅显示一次)
ActionEvent.SHOW_ACTIVITY_RED_POINT = "ActionEvent.SHOW_ACTIVITY_RED_POINT"

--沙滩争夺战
ActionEvent.Aandybeach_Boss_Fight_Action_Event = "ActionEvent.Aandybeach_Boss_Fight_Action_Event" 
ActionEvent.Aandybeach_Boss_Fight_Main_Event = "ActionEvent.Aandybeach_Boss_Fight_Main_Event"
ActionEvent.Aandybeach_Boss_Fight_Buy_Count_Event = "ActionEvent.Aandybeach_Boss_Fight_Buy_Count_Event"
ActionEvent.Aandybeach_Boss_Fight_Reward_Event = "ActionEvent.Aandybeach_Boss_Fight_Reward_Event"
ActionEvent.Aandybeach_Boss_Fight_Result_Event = "ActionEvent.Aandybeach_Boss_Fight_Result_Event"
--点击关闭结算面板之后出现动画
ActionEvent.Aandybeach_Boss_Fight_Result_Close = "ActionEvent.Aandybeach_Boss_Fight_Result_Close"

--杂货铺
ActionEvent.UPDATE_STORE_DATA_EVENT = "ActionEvent.UPDATE_STORE_DATA_EVENT"
--杂货铺 购买成功
ActionEvent.UPDATE_STORE_DATA_SUCCESS_EVENT = "ActionEvent.UPDATE_STORE_DATA_SUCCESS_EVENT"

--神装道具商店
ActionEvent.Updata_Hero_Clothes_Shop_Data = "ActionEvent.Updata_Hero_Clothes_Shop_Data"

--英雄重生选择界面返回
ActionEvent.HERO_RESET_SELECT_EVENT = "ActionEvent.HERO_RESET_SELECT_EVENT"
--重生
ActionEvent.ACTION_HERO_RESET_EVENT = "ActionEvent.ACTION_HERO_RESET_EVENT"
ActionEvent.ACTION_HERO_RESET_ITEM_EVENT = "ActionEvent.ACTION_HERO_RESET_ITEM_EVENT"

--皮肤抽奖
ActionEvent.ACTION_SKIN_LOTTERY_MSG = "ActionEvent.ACTION_SKIN_LOTTERY_MSG"
ActionEvent.ACTION_SKIN_LOTTERY_GET = "ActionEvent.ACTION_SKIN_LOTTERY_GET"
ActionEvent.ACTION_SKIN_LOTTERY_REWARD = "ActionEvent.ACTION_SKIN_LOTTERY_REWARD"

--代金券开启检测
ActionEvent.ACTION_PERFER_ISOPEN = "ActionEvent.ACTION_PERFER_ISOPEN"

ActionEvent.ACTION_PERFER_GET_DATA_EVENT = "ActionEvent.ACTION_PERFER_GET_DATA_EVENT"

--合服目标信息
ActionEvent.Merge_Aim_Event = "ActionEvent.Merge_Aim_Event"
ActionEvent.Merge_Box_Status_Event = "ActionEvent.Merge_Box_Status_Event"

 -- 基金在福利显示
ActionEvent.UPDATA_WELFARE_FUND__STATUS_EVENT = "ActionEvent.UPDATA_WELFARE_FUND__STATUS_EVENT"

-- 活动数据更新
ActionEvent.UPDATE_ACTION_DATA_EVENT = "ActionEvent.UPDATE_ACTION_DATA_EVENT"

-- 元旦充值返利
ActionEvent.UPDATE_RECHARGE_REBATE_EVENT = "ActionEvent.UPDATE_RECHARGE_REBATE_EVENT"
--精灵限时重生
ActionEvent.SPRITE_RESET_EVENT = "ActionEvent.SPRITE_RESET_EVENT"
--精灵重生选择界面返回
ActionEvent.SPRITE_RESET_SELECT_EVENT = "ActionEvent.SPRITE_RESET_SELECT_EVENT"
--幸运锦鲤基础信息
ActionEvent.LUCKY_DOG_BASE_EVENT = "ActionEvent.LUCKY_DOG_BASE_EVENT"

-- 不放回抽奖基础数据
ActionEvent.FORTUNE_BAG_DRAW_BASE_EVENT = "ActionEvent.FORTUNE_BAG_DRAW_BASE_EVENT"
-- 奖池奖励信息
ActionEvent.FORTUNE_BAG_SURPLUS_EVENT = "ActionEvent.FORTUNE_BAG_SURPLUS_EVENT"
-- 终极奖励列表
ActionEvent.FORTUNE_BAG_ULTIMATE_EVENT = "ActionEvent.FORTUNE_BAG_ULTIMATE_EVENT"

--定时领奖（神明的新春祝福）主界面入口刷新
ActionEvent.Update_Time_Collect_Main_Icon_Event = "ActionEvent.Update_Time_Collect_Main_Icon_Event"

-- 甜蜜大作战数据
ActionEvent.Update_Sweet_Data_Event = "ActionEvent.Update_Sweet_Data_Event"
-- 甜蜜大作战捐献成功
ActionEvent.Sweet_Put_Success_Event = "ActionEvent.Sweet_Put_Success_Event"
-- 白色情人节基础信息
ActionEvent.White_Day_Init_Event = "ActionEvent.White_Day_Init_Event"
-- 超值周卡基础信息
ActionEvent.SuperValueWeeklyCard_Init_Event = "ActionEvent.SuperValueWeeklyCard_Init_Event"