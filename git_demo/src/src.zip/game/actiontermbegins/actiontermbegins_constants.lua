

-- --------------------------------------------------------------------
-- 活动相关的常量
-- 
-- @description:
--      这里填写详细说明,主要填写该模块的功能简要
-- --------------------------------------------------------------------
ActiontermbeginsConstants = ActiontermbeginsConstants or {}


ActiontermbeginsConstants.TabType = {
    eChapter = 1 , -- 关卡页签
    eBoss    = 2 , -- boss页签
}