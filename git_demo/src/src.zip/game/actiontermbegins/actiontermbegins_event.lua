-- --------------------------------------------------------------------
-- 开学季活动boss战
--
-- @description:
--      开学季活动boss战 后端 锦汉 策划 建军
-- --------------------------------------------------------------------
ActiontermbeginsEvent = ActiontermbeginsEvent or {}

--协议26700主信息
ActiontermbeginsEvent.TERM_BEGINS_MAIN_EVENT = "TERM_BEGINS_MAIN_EVENT"
--购买挑战数量
ActiontermbeginsEvent.TERM_BEGINS_BUY_COUNT_EVENT = "TERM_BEGINS_BUY_COUNT_EVENT"
--提交试卷
ActiontermbeginsEvent.TERM_BEGINS_SUBIT_PAPER_EVENT = "TERM_BEGINS_SUBIT_PAPER_EVENT"
--试卷奖励列表信息
ActiontermbeginsEvent.TERM_BEGINS_PAPER_REWARD_LIST_EVENT = "TERM_BEGINS_PAPER_REWARD_LIST_EVENT"
--领取试卷事件
ActiontermbeginsEvent.TERM_BEGINS_RECEIVE_PAPER_EVENT = "TERM_BEGINS_RECEIVE_PAPER_EVENT"
--伤害排行信息
ActiontermbeginsEvent.TERM_BEGINS_RANK_EVENT = "TERM_BEGINS_RANK_EVENT"

ActiontermbeginsEvent.ACTION_TERM_BEGINS_EVENT = "ACTION_TERM_BEGINS_EVENT"

--打开布阵界面协议
ActiontermbeginsEvent.TERM_BEGINS_BOSS_FORM_EVENT = "TERM_BEGINS_BOSS_FORM_EVENT"
--更新奖励红点事件
ActiontermbeginsEvent.TERM_BEGINS_REWARD_REDPOINT_EVENT = "TERM_BEGINS_REWARD_REDPOINT_EVENT"
