-- --------------------------------------------------------------------
-- 这里填写简要说明(必填),
--
-- @description:
--      年兽活动 后端 国辉  策划 中建
-- --------------------------------------------------------------------
ActionyearmonsterEvent = ActionyearmonsterEvent or {}

--年兽基本信息
ActionyearmonsterEvent.YEAR_MONSTER_BASE_INFO = "YEAR_MONSTER_BASE_INFO"
--格子信息
ActionyearmonsterEvent.YEAR_MONSTER_CEIL_INFO = "YEAR_MONSTER_CEIL_INFO"
ActionyearmonsterEvent.YEAR_UPDATE_GRID_EVENT = "YEAR_UPDATE_GRID_EVENT"
ActionyearmonsterEvent.YEAR_Add_Evt_Data_Event = "YEAR_Add_Evt_Data_Event"

--事件
ActionyearmonsterEvent.Year_Update_Evt_Status_Event = "Year_Update_Evt_Status_Event"
--通知进入格子
ActionyearmonsterEvent.Year_Update_Role_Grid_Event = "Year_Update_Role_Grid_Event"
--敌方阵容
ActionyearmonsterEvent.Year_Get_Master_Data_Event = "Year_Get_Master_Data_Event"

--背包操作事件
ActionyearmonsterEvent.Year_Iint_Bag_Data_Event = "Year_Iint_Bag_Data_Event"
ActionyearmonsterEvent.Year_Update_Bag_Data_Event = "Year_Update_Bag_Data_Event"
ActionyearmonsterEvent.Year_Delete_Bag_Data_Event = "Year_Delete_Bag_Data_Event"

--提交祭品
ActionyearmonsterEvent.Year_Submit_item_Event = "Year_Submit_item_Event"
--购买次数
ActionyearmonsterEvent.Year_Buy_count_Event = "Year_Buy_count_Event"

--排行奖励
ActionyearmonsterEvent.Year_Rank_Info_Event = "Year_Rank_Info_Event"

--集字兑换界面信息
ActionyearmonsterEvent.UPDATE_EXCHANGE_DATA_EVENT = "UPDATE_EXCHANGE_DATA_EVENT"

--表情界面信息
ActionyearmonsterEvent.Year_Face_Event = "Year_Face_Event"
--播放烟花特效
ActionyearmonsterEvent.Year_Five_Effect_Event = "Year_Five_Effect_Event"
--表情发送
ActionyearmonsterEvent.Year_Send_Face_Event = "Year_Send_Face_Event"
--其他玩家数据
ActionyearmonsterEvent.Year_Other_Role_Event = "Year_Other_Role_Event"
--更新主界面红包入口显示
ActionyearmonsterEvent.Update_Year_Main_Redbag_Event = "Update_Year_Main_Redbag_Event"



